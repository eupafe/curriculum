package presentation.view;
import business.entities.League;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseListener;
import java.util.ArrayList;

/**
 * View that shows the admin a list of the created leagues. It has 2 buttons: CREATE LEAGUE and DELETE LEAGUE.
 */
public class PlayerMainView extends JPanel{

    /**
     * View identifier
     */
    public static final String IDENTIFIER = "PlayerMainView";

    private static ArrayList<String> leagues = new ArrayList<>();

    private static JList<String> leaguesList = new JList<>();

    private static DefaultTableModel model;
    private static JTable table;

    /**
     * Constructor
     */
    public PlayerMainView() {
        configureView();
    }

    /**
     * Configures the view of the JPanel with a Border layout. Inside there is a Jlabel
     * at the north and a JTable in the center.
     */
    private void configureView() {

        // Create the nested Border layout for the center
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(Color.BLACK);
        centerPanel.setPreferredSize(new Dimension(1200, 700));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));

        // Add the JLabel to the north
        JLabel createTeamsLabel = new JLabel("My Leagues");
        //createTeamsLabel.setPreferredSize(new Dimension(0, 100));
        createTeamsLabel.setFont(new Font("Kreon", Font.BOLD, 60));
        createTeamsLabel.setForeground(Color.WHITE);
        centerPanel.add(createTeamsLabel, BorderLayout.NORTH);

        // Add the JList to the center

        // Create the DefaultTableModel with the data and column names
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Disable cell editing for all cells
                return false;
            }
        };

        model.addColumn("LEAGUE NAME");
        model.addColumn("STATUS");
        model.addColumn("# TEAMS");

        table = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(table);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        // Add the centerPanel to the center of the main BorderLayout
        add(centerPanel, BorderLayout.CENTER);

    }

    /**
     * Method that shows the view
     */
    public void start() {
        setVisible(true);
    }

    /**
     * Method that updates the League JTable given an arraylist of leagues, strings and integers.
     * @param leagueObjects
     * @param status
     * @param numTeams
     */

    public void updateLeagueList(ArrayList<League> leagueObjects, ArrayList<String> status,ArrayList<Integer> numTeams ){

        model.setRowCount(0);

        for (int i = 0; i < leagueObjects.size(); i++) {
            model.addRow(new Object[] { leagueObjects.get(i).getName(), status.get(i), numTeams.get(i) });
        }
        table.setModel(model);
    }

    /**
     * Function that adds the Mouse Listener to the JTable of the view.
     * @param mouseListener
     */
    public void registerController(MouseListener mouseListener ){
        table.addMouseListener(mouseListener);
    }

    /**
     * Method that returns the JTable.
     * @return JTable of the view.
     */
    public JTable getTable() {
        return table;
    }
}

