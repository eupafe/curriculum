package presentation.view;
import business.UserManager;
import business.entities.League;
import business.entities.Team;
import business.entities.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

/**
 * View that shows the admin a list of the created players after uploading the JSON file.
 * This list contains both the DNI and the PASSWORD of the new created players.
 */
public class CreatedPlayersView extends JPanel {

    /**
     * View identifier
     */
    public static final String IDENTIFIER = "CreatedPlayersView";

    private static DefaultTableModel model;
    private static JTable table;

    /**
     * Constructor
     */
    public CreatedPlayersView() {
        configureView();
    }

    /**
     * Method that configures the view as a whole with the JTable, JLabel and scroll panel.
     */
    private void configureView(){

        setLayout(new GridBagLayout());

        // Create the DefaultTableModel with the data and column names
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Disable cell editing for all cells
                return false;
            }
        };

        model.addColumn("DNI");
        model.addColumn("PASSWORD");

        table = new JTable(model);

        // Create a JLabel for the title
        JLabel titleLabel = new JLabel("Created Players");
        titleLabel.setFont(new Font("Kreon", Font.BOLD, 60));
        titleLabel.setForeground(Color.WHITE); // Set text color to white
        Font boldFont = new Font(titleLabel.getFont().getName(), Font.BOLD, titleLabel.getFont().getSize());
        titleLabel.setFont(boldFont); // Set font to bold

        // Create a JPanel for the title
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(Color.BLACK); // Set background color to black
        //titlePanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); // Add padding
        titlePanel.add(titleLabel);

        // Create a JScrollPane
        JScrollPane scrollPane = new JScrollPane(table);

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0; //X position in the grid
        constraints.gridy = 0; // Y position in the grid
        constraints.fill = GridBagConstraints.HORIZONTAL; //Fill horizontally
        constraints.weightx = 1.0; // Expand horizontally

        add(titlePanel, constraints);

        // Update the constraints for the table scroll pane
        constraints.gridy = 1; // Move to the next row
        constraints.fill = GridBagConstraints.BOTH; // Fill both horizontally and vertically
        constraints.weighty = 1.0; // Expand vertically

        add(scrollPane, constraints);

    }

    /**
     * Updates the JTable given an arraylist of user.
     * @param userObjects list of users
     */
    public void updateList(ArrayList<User> userObjects){
        model.setRowCount(0);

        for (User user : userObjects) {
            model.addRow(new Object[] { user.getDNI(), user.getPassword() });
        }

        table.setModel(model);
    }

}
