package presentation.view;

import business.entities.Team;
import business.entities.User;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseListener;
import java.util.ArrayList;

/**
 * View that list the players that a Team has in a JTable.
 */
public class ListPlayersView extends JPanel {
    /**
     * View identifier
     */
    public static final String IDENTIFIER = "ListPlayersView";

    private JLabel teamLabel;
    private JTable table;
    private JButton button;
    private static DefaultTableModel model;

    /**
     * Constructor
     */
    public ListPlayersView() {
        configureView();
    }

    /**
     * This method configures the view, sets the background, creates a JTable and a JButton.
     */
    private void configureView(){
        this.setBackground(Color.BLACK);

        // Create the DefaultTableModel with the data and column names
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Disable cell editing for all cells
                return false;
            }
        };

        model.addColumn("NAME");
        model.addColumn("DNI");
        model.addColumn("EMAIL");
        model.addColumn("SQ_NUM");
        model.addColumn("PHONE");

        table = new JTable(model);

        DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) table.getTableHeader().getDefaultRenderer();
        headerRenderer.setFont(headerRenderer.getFont().deriveFont(Font.BOLD));
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBackground(Color.BLACK);
        teamLabel = new JLabel("");
        teamLabel.setForeground(Color.WHITE);
        teamLabel.setHorizontalAlignment(SwingConstants.CENTER);
        button = new JButton("Go back");
        button.setActionCommand("GO_BACK_BUTTON");

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Color.BLACK);

        teamLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(teamLabel);
        panel.add(Box.createVerticalStrut(10));
        scrollPane.setPreferredSize(new Dimension(800, 300));
        panel.add(scrollPane);
        panel.add(Box.createVerticalStrut(30));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(button);

        add(panel);

        Font headerFont = table.getTableHeader().getFont();
        Font boldHeaderFont = headerFont.deriveFont(Font.BOLD);
        table.getTableHeader().setFont(boldHeaderFont);

        Font cellFont = table.getFont();
        Font boldCellFont = cellFont.deriveFont(Font.BOLD);

        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer();
        cellRenderer.setFont(boldCellFont);

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(cellRenderer);
        }

    }

    /**
     * This function sets the team label according to the name given.
     * @param name
     */
    public void setLeagueLabel(String name){

        Font currentFont = teamLabel.getFont();
        int currentSize = currentFont.getSize();
        int desiredSize = 24;

        if (currentSize != desiredSize) {
            Font biggerFont = currentFont.deriveFont(Font.PLAIN, desiredSize);
            teamLabel.setFont(biggerFont);
        }
        teamLabel.setText(name);

    }

    /**
     * Registers the provided ActionListener to the button.
     * @param listener
     */
    public void registerController(ActionListener listener ){
        button.addActionListener(listener);
    }

    /**
     * Updates the JTable given an arraylist of users.
     * @param userObjects
     */
    public void updatePlayerList(ArrayList<User> userObjects){
        model.setRowCount(0);

        for (User user : userObjects) {
            model.addRow(new Object[] { user.getName(), user.getDNI(), user.getEmail(), user.getSquadNumber(), user.getPhone()});
        }

        table.setModel(model);
    }
}
