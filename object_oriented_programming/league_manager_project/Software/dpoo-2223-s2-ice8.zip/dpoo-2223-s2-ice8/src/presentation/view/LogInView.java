package presentation.view;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.*;

/**
 * View that allows the user to log in. It asks for the DNI/email and the password.
 */
public class LogInView extends JPanel {

    /**
     * View identifier
     */
    public static final String IDENTIFIER = "LogInView";

    // JTextFields
    private static JTextField userTextField;
    private static JTextField passwordTextField;
    // JLabel
    private static JLabel messageLabel;
    // JButton
    private static JButton button;

    /**
     * Constructor
     */
    public LogInView() {
        configureView();
    }

    /**
     * Configures the main contents and set the background image
     */
    private void configureView() {
        setLayout(new BorderLayout());

        JPanel gridPanel = createGridPanel();
        add(gridPanel);
    }

    /**
     * Configures a JPanel with a GridBagLayout to display multiple panels in a vertical layout.
     * @return gridPanel
     */
    private JPanel createGridPanel(){
        JPanel gridPanel = new JPanel(new GridBagLayout());
        gridPanel.setBackground(Color.BLACK);
        gridPanel.setLayout(new BoxLayout(gridPanel, BoxLayout.PAGE_AXIS));

        GridBagConstraints c = new GridBagConstraints();

        JPanel panel1 = createHeader();

        JPanel panel2 = createUsernameSettings();

        JPanel panel3 = createPasswordSettings();

        JPanel panel4 = createJLabelMessage();

        JPanel panel5 = createLogIn();
        c.weighty = 1.0;
        c.fill = GridBagConstraints.VERTICAL;

        // Restrictions 1st panel
        c.gridx = 0;
        c.gridy = 1;
        c.gridheight = 2;
        gridPanel.add(panel1, c);

        // Restrictions 2nd panel
        c.gridx = 0;
        c.gridy = 3;
        c.gridheight = 1;
        gridPanel.add(panel2, c);

        // Restrictions 3rd panel
        c.gridx = 0;
        c.gridy = 4;
        gridPanel.add(panel3, c);

        // Restrictions 4th panel
        c.gridx = 0;
        c.gridy = 5;
        gridPanel.add(panel4, c);

        // Restrictions 5th panel
        c.gridx = 0;
        c.gridy = 6;
        gridPanel.add(panel5, c);

        return gridPanel;
    }

    /**
     * Creates a JPanel for the header settings which contains two JLabels.
     * @return header panel
     */
    private JPanel createHeader(){

        JPanel header = new JPanel(new GridBagLayout());
        header.setBackground(Color.BLACK);
        Dimension cellSize1 = new Dimension(50, 150);
        header.setPreferredSize(cellSize1);

        JLabel titleApp = new JLabel("LM 2023");
        titleApp.setFont(new Font("Kranky-Regular", Font.PLAIN, 50));
        titleApp.setForeground(Color.WHITE);

        JLabel subtitleApp = new JLabel("League Manager");
        subtitleApp.setFont(new Font("Kreon", Font.BOLD, 20));
        subtitleApp.setForeground(Color.WHITE);

        GridBagConstraints gbc1 = new GridBagConstraints();
        gbc1.gridx = 0;
        gbc1.gridy = 0;
        gbc1.gridwidth = 1;
        gbc1.gridheight = 1;
        gbc1.anchor = GridBagConstraints.NORTHWEST;

        GridBagConstraints gbc2 = new GridBagConstraints();
        gbc2.gridx = 1;
        gbc2.gridy = 1;
        gbc2.gridwidth = 1;
        gbc2.gridheight = 1;
        gbc2.anchor = GridBagConstraints.SOUTHEAST;

        header.add(titleApp, gbc1);
        header.add(subtitleApp, gbc2);

        GridBagConstraints gbc3 = new GridBagConstraints();
        gbc3.gridx = 0;
        gbc3.gridy = 0;
        gbc3.gridwidth = 1;
        gbc3.gridheight = 1;
        gbc3.anchor = GridBagConstraints.CENTER;

        return header;
    }

    /**
     * Creates a JPanel with a JButton.
     * @return JPanel
     */
    private JPanel createLogIn(){
        JPanel panel4 = new JPanel();
        panel4.setBackground(Color.BLACK);
        Dimension cellSize4 = new Dimension(50, 60);
        panel4.setPreferredSize(cellSize4);

        button = new JButton("Log In");
        button.setFont(new Font("Kreon", Font.BOLD, 15));
        button.setBackground(Color.WHITE);
        button.setActionCommand("LOG_IN");
        panel4.add(button);

        return panel4;
    }

    /**
     * Creates a JPanel with the JLabel and a TextField.
     * @return username panel
     */
    private JPanel createUsernameSettings(){

        JPanel panel2 = new JPanel();
        panel2.setBackground(Color.BLACK);
        panel2.setLayout(new BoxLayout(panel2, BoxLayout.Y_AXIS));
        Dimension cellSize2 = new Dimension(50, 120);
        panel2.setPreferredSize(cellSize2);

        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setFont(new Font("Inter", Font.BOLD, 10));
        usernameLabel.setForeground(Color.WHITE);
        Component verticalSpacer1 = Box.createRigidArea(new Dimension(0, 7));
        Component verticalSpacer2 = Box.createRigidArea(new Dimension(0, 7));
        userTextField = new JTextField("Type your DNI / Email");
        userTextField.setFont(new Font("Inter", Font.BOLD, 12));

        userTextField.addFocusListener(new FocusAdapter() {

            @Override
            public void focusGained(FocusEvent e) {
                if (userTextField.getText().equals("Type your DNI / Email")) {
                    userTextField.setText("");
                }
            }
            @Override
            public void focusLost(FocusEvent e) {
                if (userTextField.getText().equals("")) {
                    userTextField.setText("Type your DNI / Email");
                }
            }
        });

        panel2.add(verticalSpacer1);
        panel2.add(usernameLabel);
        panel2.add(verticalSpacer2);
        panel2.setBorder(BorderFactory.createEmptyBorder(15, 40, 10, 40));
        panel2.add(userTextField);

        return panel2;
    }

    /**
     * Creates a JPanel with the JLabel and a PasswordField.
     * @return password panel
     */
    private JPanel createPasswordSettings(){

        JPanel panel3 =  new JPanel();
        panel3.setBackground(Color.BLACK);
        panel3.setLayout(new BoxLayout(panel3, BoxLayout.Y_AXIS));
        Dimension cellSize3 = new Dimension(50, 190);
        panel3.setPreferredSize(cellSize3);

        JLabel usernameLabel = new JLabel("Password");
        usernameLabel.setFont(new Font("Inter", Font.BOLD, 10));
        usernameLabel.setForeground(Color.WHITE);
        Component verticalSpacer1 = Box.createRigidArea(new Dimension(0, 7));
        Component verticalSpacer2 = Box.createRigidArea(new Dimension(0, 7));
        passwordTextField = new JPasswordField(20);
        passwordTextField.setFont(new Font("Inter", Font.BOLD, 12));

        panel3.add(verticalSpacer1);
        panel3.add(usernameLabel);
        panel3.add(verticalSpacer2);
        panel3.setBorder(BorderFactory.createEmptyBorder(15, 40, 10, 40));
        panel3.add(passwordTextField);

        Component verticalSpacer3 = Box.createRigidArea(new Dimension(0, 10));
        panel3.add(verticalSpacer3);

        return panel3;
    }

    /**
     * Creates a Jpanel with an empty message Label.
     * @return JPanel with the JLabel
     */
    private JPanel createJLabelMessage(){

        JPanel panel3 =  new JPanel();
        panel3.setBackground(Color.BLACK);
        //panel3.setLayout(new BoxLayout(panel3, BoxLayout.Y_AXIS));
        Dimension cellSize3 = new Dimension(50, 80);
        panel3.setPreferredSize(cellSize3);

        messageLabel = new JLabel("");
        //Border margin = BorderFactory.createEmptyBorder(10, 30, 10, 30); // Margen de 10 píxeles arriba y abajo
        //messageLabel.setBorder(margin);
        //messageLabel.setHorizontalAlignment(SwingConstants.LEFT);

        panel3.add(messageLabel);



        /*
        passwordTextField.addFocusListener(new FocusAdapter() {

            @Override
            public void focusGained(FocusEvent e) {
                if (passwordTextField.getText().equals("Type your password")) {
                    passwordTextField.setText(""); // Si el texto es el predeterminado, eliminarlo
                }
            }
            @Override
            public void focusLost(FocusEvent e) {
                if (passwordTextField.getText().equals("")) {
                    passwordTextField.setText("Type your password"); // Si el usuario no ingresó nada, volver al texto predeterminado
                }
            }
        });*/

        return panel3;
    }

    /**
     * Shows the view
     */
    public void start() {

        setVisible(true);
    }

    /**
     * Function that returns the username that the user has entered.
     * @return String with the username
     */
    public String getUsername() {
        return userTextField.getText();
    }

    /**
     * Function that returns the password that the user has entered.
     * @return String with the password
     */
    public String getPassword() {
        return passwordTextField.getText();
    }

    /**
     * Adds the listener to the Log In button.
     * @param listener
     */
    public void registerController(ActionListener listener) {
        button.addActionListener(listener);
    }

    /**
     * Method that sets the border of both user and password text field.
     * @param border
     */
    public void setLoginFieldsBorder(Border border) {
        userTextField.setBorder(border);
        passwordTextField.setBorder(border);
    }

    /**
     * Method that sets the message JLabel.
     * @param text
     * @param color
     */
    public void setMessageLabelText(String text, Color color) {
        messageLabel.setText("<html>" + text.replaceAll("\n", "<br>") + "</html>");
        messageLabel.setForeground(color);
        messageLabel.setHorizontalAlignment(JLabel.CENTER);
        messageLabel.setMinimumSize(new Dimension(20, 20));

    }

    /**
     * Method that resets the user text field and password text field.
     */
    public void reset() {
        userTextField.setText("Type your DNI / Email");
        passwordTextField.setText("");
    }
}
