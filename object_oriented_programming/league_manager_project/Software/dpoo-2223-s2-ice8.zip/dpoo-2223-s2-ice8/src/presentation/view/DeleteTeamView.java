
package presentation.view;

import business.entities.Team;

import javax.swing.*;
import javax.swing.plaf.synth.SynthOptionPaneUI;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * View that shows the admin a checkBox where he/she can select the teams to delete.
 */
public class DeleteTeamView extends JPanel {

    /**
     * View identifier
     */
    public static final String IDENTIFIER = "DeleteTeamView";
    private static ArrayList<JCheckBox> checkBoxes = new ArrayList<>();
    private static JButton addButton;
    private static JPanel contentPanel;

    /**
     * Constructor
     */
    public DeleteTeamView() {
        configureView();
    }

    /**
     * This function configures the view by setting up the layout, borders and
     * JLabel together with the checkboxes, and a delete button.
     */
    private void configureView() {

        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setBackground(Color.BLACK);

        // Title
        JLabel titleLabel = new JLabel("Choose the teams you want to delete: ");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 40));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        add(titleLabel, BorderLayout.NORTH);

        // CheckBox panel
        contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        add(contentPanel, BorderLayout.CENTER);

        //JScrollPane scrollPane = new JScrollPane(teamList);
        //contentPanel.add(scrollPane);

        // Button
        addButton = new JButton("DELETE TEAM");
        addButton.setFont(new Font("Arial", Font.PLAIN, 16));
        addButton.setActionCommand("FINAL_DELETE_TEAM");
        add(addButton, BorderLayout.SOUTH);
    }

    /**
     * Function that given an arraylist of teams, updates the checkboxes shown to the user.
     * @param teamObjects
     */
    public void updateTeamList(ArrayList<Team> teamObjects){
        contentPanel.removeAll();
        checkBoxes.clear();

        for (Team team : teamObjects) {
            JCheckBox jCheckBox = new JCheckBox(team.getName());
            jCheckBox.setFont(new Font("Arial", Font.BOLD, 30));
            contentPanel.add(jCheckBox);
            checkBoxes.add(jCheckBox);
        }
    }

    /**
     * Returns the selected checkboxes as a list of strings.
     * @return arraylist of strings
     */
    public ArrayList<String> getCheckBoxes(){

        ArrayList<String> selected = new ArrayList<>();

        for(JCheckBox checkBox: checkBoxes){
            if(checkBox.isSelected()){
                selected.add(checkBox.getText());
            }
        }

        return selected;
    }

    /**
     * Shows the view
     */
    public void start() {
        setVisible(true);
    }

    /**
     * Function that given a listener, it sets it to the add button to be able to know
     * when the user has pressed it.
     * @param listener
     */
    public void registerController(ActionListener listener) {
        addButton.addActionListener(listener);
    }

}
