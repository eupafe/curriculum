package presentation.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * View that shows the admin three buttons: TEAMS, LEAGUES, STATISTICS
 */
public class AdminMainView extends JPanel {

    /**
     * View identifier
     */
    public static final String IDENTIFIER = "AdminMainView";

    //JButtons
    private JButton teamsButton;
    private JButton leaguesButton;

    /**
     * Constructor
     */
    public AdminMainView() {
        configureView();
    }

    /**
     * Method that configures the view as a whole with the JPanels and buttons.
     */
    private void configureView() {

        // Panel for the buttons
        JPanel gridPanel = new JPanel(new GridBagLayout());
        gridPanel.setBackground(Color.BLACK);
        gridPanel.setPreferredSize(new Dimension(1400, 700));
        gridPanel.setBorder(BorderFactory.createEmptyBorder(10, 100, 10, 100));

        // Create the three buttons for the GridLayout
        teamsButton = new JButton("TEAMS");
        teamsButton.setFont(new Font("Kreon", Font.BOLD, 40));
        teamsButton.setBackground(Color.WHITE);
        teamsButton.setActionCommand("TEAMS_BUTTON");

        leaguesButton = new JButton("LEAGUES");
        leaguesButton.setFont(new Font("Kreon", Font.BOLD, 40));
        leaguesButton.setBackground(Color.WHITE);
        leaguesButton.setActionCommand("LEAGUES_BUTTON");

        // Configure grid sizes
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 1; // column 1
        gbc.gridy = 0; // row 0
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(50, 10, 50, 10);
        gbc.weightx = 1;
        gbc.weighty = 1;
        gridPanel.add(teamsButton, gbc);
        gbc.gridy = 1; // row 1
        gridPanel.add(leaguesButton, gbc);

        // Add empty black panels to the left and right of the buttons
        gbc.gridx = 0; // column 0
        gbc.fill = GridBagConstraints.BOTH; // fill entire cell
        JPanel emptyPanelLeft = new JPanel();
        emptyPanelLeft.setBackground(Color.BLACK);
        gridPanel.add(emptyPanelLeft, gbc);
        gbc.gridx = 2; // column 2
        JPanel emptyPanelRight = new JPanel();
        emptyPanelRight.setBackground(Color.BLACK);
        gridPanel.add(emptyPanelRight, gbc);

        // Add the gridPanel to the center of the BorderLayout
        add(gridPanel, BorderLayout.CENTER);

    }

    /**
     * Registers an ActionListener event handler for the TEAMS, LEAGUES and STATISTICS buttons
     * @param listener the ActionListener to register
     */
    public void registerController(ActionListener listener) {
        teamsButton.addActionListener(listener);
        leaguesButton.addActionListener(listener);
    }

    /**
     * Method that shows the view on the screen
     */
    public void start() {
        setVisible(true);
    }

}
