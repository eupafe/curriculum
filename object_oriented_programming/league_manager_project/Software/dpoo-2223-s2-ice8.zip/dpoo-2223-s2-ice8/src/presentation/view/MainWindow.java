package presentation.view;

import javax.swing.*;
import java.awt.*;

/**
 * Main view that contains a CardLayout to change from Login to the other Views
 */
public class MainWindow extends JFrame {

    private CardLayout cardLayout = new CardLayout();
    private JPanel cardPanel = new JPanel(cardLayout);

    /**
     * Constructor
     */
    public MainWindow(){
        configureView();
    }

    /**
     * Method that configures the title, image icon and size of the main window.
     */
    private void configureView(){

        getContentPane().add(cardPanel);

        setTitle("LM 2023");
        ImageIcon icon = new ImageIcon("Icons/leagueManagerlogo.png");
        setIconImage(icon.getImage());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 600);
        setResizable(true);
    }

    /**
     * Adds a specific view to the CardLayout
     */
    public void addToCardLayout(String identifier, JPanel view) {
       cardPanel.add(view, identifier);
    }

    /**
     * Sets the desired View to the cardPanel
     */
    public void setChangeView(String identifier){
        cardLayout.show(cardPanel, identifier);
    }

    /**
     * Shows the view
     */
    public void start() {
        setVisible(true);
    }
}
