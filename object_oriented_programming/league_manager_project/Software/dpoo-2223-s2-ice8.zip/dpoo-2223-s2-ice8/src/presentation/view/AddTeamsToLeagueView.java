package presentation.view;

import business.entities.Team;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * View that shows the user a checkBox to select the teams they want to add to a league
 */

public class AddTeamsToLeagueView extends JPanel {

    /**
     * View identifier
     */
    public static final String IDENTIFIER = "AddTeamsToLeagueView";
    private static ArrayList<JCheckBox> checkBoxes = new ArrayList<>();
    private static JButton createButton;
    private static JPanel contentPanel;

    /**
     * Constructor
     */
    public AddTeamsToLeagueView() {
        configureView();
    }

    /**
     * Method that configures the JPanels, Layout used as well as JLabel and checkboxes.
     */
    private void configureView() {

        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setBackground(Color.BLACK);

        // Title
        JLabel titleLabel = new JLabel("Choose the teams you want to add: ");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 40));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        add(titleLabel, BorderLayout.NORTH);

        // CheckBox panel
        contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        add(contentPanel, BorderLayout.CENTER);

        //JScrollPane scrollPane = new JScrollPane(teamList);
        //contentPanel.add(scrollPane);

        // Button
        createButton = new JButton("CREATE LEAGUE");
        createButton.setFont(new Font("Arial", Font.PLAIN, 16));
        createButton.setActionCommand("FINAL_CREATE_LEAGUE");
        add(createButton, BorderLayout.SOUTH);
    }

    /**
     * Function that given an arraylist of teams, updates the checkboxes to show that information to the user.
     * @param teamObjects
     */
    public void updateTeamList(ArrayList<Team> teamObjects){
        contentPanel.removeAll();
        checkBoxes.clear();

        for (Team team : teamObjects) {
            JCheckBox jCheckBox = new JCheckBox(team.getName());
            jCheckBox.setFont(new Font("Arial", Font.BOLD, 30));
            contentPanel.add(jCheckBox);
            checkBoxes.add(jCheckBox);
        }
    }

    /**
    *
     * Function that returns the selected checkboxes from the list of checkboxes
     * @return An ArrayList of Strings containing the text of the selected checkboxes.
     */
    public ArrayList<String> getCheckBoxes(){

        ArrayList<String> selected = new ArrayList<>();

        for (JCheckBox checkBox : checkBoxes) {
            if (checkBox.isSelected()) {
                selected.add(checkBox.getText());
            }
        }

        return selected;
    }

    /**
     * Registers an ActionListener event handler for the FINAL_CREATE_LEAGUE button
     * @param listener the ActionListener to register
     */
    public void registerController(ActionListener listener) {
        createButton.addActionListener(listener);
    }

}