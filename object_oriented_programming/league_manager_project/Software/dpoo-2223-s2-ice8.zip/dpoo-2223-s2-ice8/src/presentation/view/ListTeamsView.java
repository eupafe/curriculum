package presentation.view;

import business.entities.Team;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.util.ArrayList;

/**
 * View that list the teams that a League has in a JTable.
 */
public class ListTeamsView extends JPanel {
    /**
     * View identifier
     */
    public static final String IDENTIFIER = "ListLeaguesView";

    private JLabel leagueLabel;

    private JTable table;

    private JButton button;

    private static DefaultTableModel model;

    /**
     * Constructor
     */
    public ListTeamsView() {
        configureView();
    }

    /**
     * This method configures the view, sets the background, creates a JTable and a JButton.
     */
    public void configureView(){

        this.setBackground(Color.BLACK);

        // Create the DefaultTableModel with the data and column names
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Disable cell editing for all cells
                return false;
            }
        };

        model.addColumn("TEAM");
        model.addColumn("MATCHES");
        model.addColumn("WON");
        model.addColumn("LOST");
        model.addColumn("TIED");
        model.addColumn("POINTS");
        model.addColumn("# PLAYERS");

        table = new JTable(model);

        DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) table.getTableHeader().getDefaultRenderer();
        headerRenderer.setFont(headerRenderer.getFont().deriveFont(Font.BOLD));
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBackground(Color.BLACK);
        leagueLabel = new JLabel("");
        leagueLabel.setForeground(Color.WHITE);
        leagueLabel.setHorizontalAlignment(SwingConstants.CENTER);
        button = new JButton("Show statistics");
        button.setActionCommand("SHOW_STATS_BUTTON");

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Color.BLACK);

        leagueLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(leagueLabel);
        panel.add(Box.createVerticalStrut(10));
        scrollPane.setPreferredSize(new Dimension(500, 300));
        panel.add(scrollPane);
        panel.add(Box.createVerticalStrut(30));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(button);

        add(panel);

        Font headerFont = table.getTableHeader().getFont();
        Font boldHeaderFont = headerFont.deriveFont(Font.BOLD);
        table.getTableHeader().setFont(boldHeaderFont);

        Font cellFont = table.getFont();
        Font boldCellFont = cellFont.deriveFont(Font.BOLD);

        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer();
        cellRenderer.setFont(boldCellFont);

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(cellRenderer);
        }

    }

    /**
     * This function sets the league label according to the name given.
     * @param name
     */
    public void setLeagueLabel(String name){

        Font currentFont = leagueLabel.getFont();
        int currentSize = currentFont.getSize();
        int desiredSize = 24;

        if (currentSize != desiredSize) {
            Font biggerFont = currentFont.deriveFont(Font.PLAIN, desiredSize);
            leagueLabel.setFont(biggerFont);
        }
        leagueLabel.setText(name);

    }

    /**
     * This method receives two listeners, ActionListener and MouseListener and activates them
     * for the button and JTable respectively.
     * @param listener
     * @param mouseListener
     */
    public void registerController(ActionListener listener, MouseListener mouseListener ){
        button.addActionListener(listener);
        table.addMouseListener(mouseListener);

    }

    /**
     * This functions updates the JTable given an arraylist of teams and 4 lists of integers with
     * different informatipn such as the matchesWon and number of Players.
     * @param teamsObjects
     * @param matchesWon
     * @param matchesLost
     * @param matchesTied
     * @param numPlayers
     */
    public void updateTeamList(ArrayList<Team> teamsObjects, ArrayList<Integer> matchesWon, ArrayList<Integer> matchesLost, ArrayList<Integer> matchesTied,
                                ArrayList<Integer> numPlayers){
        model.setRowCount(0);
        int totalMatches = 0;
        int score = 0;

        for (int i = 0; i < teamsObjects.size(); i++) {
            totalMatches = matchesWon.get(i) + matchesLost.get(i) + matchesTied.get(i);
            score = matchesWon.get(i);
            model.addRow(new Object[] { teamsObjects.get(i).getName(), totalMatches, matchesWon.get(i), matchesLost.get(i),
                                        matchesTied.get(i), score, numPlayers.get(i)});
        }
        table.setModel(model);
    }

    /**
     * This method returns the JTable of the view.
     * @return JTable
     */

    public JTable getTable() {
        return table;
    }
}
