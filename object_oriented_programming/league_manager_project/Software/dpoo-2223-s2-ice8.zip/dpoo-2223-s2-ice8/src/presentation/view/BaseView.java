package presentation.view;

import business.entities.Match;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * Base view that contains the back arrow, the settings button and the liveStreaming.
 * It has a cardLayout to be able to switch views.
 */

public class BaseView extends JPanel{

    /**
     * View identifier
     */
    public static final String IDENTIFIER = "BaseView";

    //JButtons
    private JButton settingsButton;
    private JButton homeButton;

    // Settings Pop Up Menu
    private JPopupMenu menu;
    private JMenuItem changePassword;
    private JMenuItem deleteAccount;
    private JMenuItem logout;

    // Other components
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel cardLayoutPanel = new JPanel(cardLayout);

    private static DefaultTableModel model;
    private static JTable table;

    /**
     * Constructor
     */
    public BaseView(){
        configureView();
    }

    /**
     * Method that configures the view as a whole with the card layout, settings panel and live streaming.
     */
    private void configureView() {

        setLayout(new BorderLayout());

        // Settings panel
        JPanel settingsPanel = settingsButton();
        add(settingsPanel, BorderLayout.NORTH);

        // Live-streaming panel
        JPanel liveStreamingPanel = liveStreaming();
        add(liveStreamingPanel, BorderLayout.EAST);

        // Card layout panel
        add(cardLayoutPanel, BorderLayout.CENTER);

        // Settings options
        changePassword = new JMenuItem("Change password");
        changePassword.setActionCommand("CHANGE_PASSWORD");
        deleteAccount = new JMenuItem("Delete account");
        deleteAccount.setActionCommand("DELETE_ACCOUNT");
        logout = new JMenuItem("Log out");
        logout.setActionCommand("LOG_OUT");

    }

    /**
     * Method that creates the settings Panel with the Image icon of settings and home.
     * @return JPanel with the whole settings JPanel
     */
    private JPanel settingsButton(){

        // Settings button creation
        ImageIcon icon = new ImageIcon("Icons/settings.png");
        settingsButton = new JButton(icon);
        settingsButton.setBorderPainted(false);
        settingsButton.setFocusPainted(false);
        settingsButton.setContentAreaFilled(false);

        // Panel for the settings button
        JPanel settingsPanel = new JPanel(new BorderLayout());
        settingsPanel.setBackground(Color.BLACK);
        settingsPanel.setPreferredSize(new Dimension(500, 100));

        // Empty border to the button to create a right margin
        settingsButton.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));
        settingsButton.setActionCommand("SETTINGS_BUTTON");

        // Back arrow button creation
        ImageIcon icon2 = new ImageIcon("Icons/home.png");
        homeButton = new JButton(icon2);
        homeButton.setBorderPainted(false);
        homeButton.setFocusPainted(false);
        homeButton.setContentAreaFilled(false);
        homeButton.setActionCommand("HOME_BUTTON");

        // Empty border to the button to create a left margin
        homeButton.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));

        // Empty border to the button to create a right margin
        homeButton.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));

        settingsPanel.add(homeButton, BorderLayout.WEST);
        settingsPanel.add(settingsButton, BorderLayout.EAST);

        return settingsPanel;

    }

    /**
     * Creates and returns a JPanel for displaying a livestreaming section.
     * The panel includes a table for displaying live scores between two teams.
     * @return JPanel with the live streaming
     */
    private JPanel liveStreaming() {

        // Panel for the livestreaming
        JPanel liveStreaming = new JPanel(new GridBagLayout());
        liveStreaming.setBackground(Color.WHITE);
        liveStreaming.setPreferredSize(new Dimension(500, 0));
        liveStreaming.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));

        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Disable cell editing for all cells
                return false;
            }
        };

        model.addColumn("TEAM 1");
        model.addColumn("SCORE 1");
        model.addColumn("VS");
        model.addColumn("SCORE 2");
        model.addColumn("TEAM 2");

        table = new JTable(model);

        // Create a JScrollPane
        JScrollPane scrollPane = new JScrollPane(table);

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0; //X position in the grid
        constraints.gridy = 0; // Y position in the grid
        constraints.fill = GridBagConstraints.HORIZONTAL; //Fill horizontally
        constraints.weightx = 1.0; // Expand horizontally

        // Update the constraints for the table scroll pane
        constraints.gridy = 1; // Move to the next row
        constraints.fill = GridBagConstraints.BOTH; // Fill both horizontally and vertically
        constraints.weighty = 1.0; // Expand vertically

        liveStreaming.add(scrollPane, constraints);

        add(liveStreaming, BorderLayout.EAST);

        return liveStreaming;

    }

    /**
     * Method that gets the identifier and the view and add its to the card layout of the baseview.
     * @param identifier of the view
     * @param view
     */
    public void addToCardLayout(String identifier, JPanel view) {
        cardLayoutPanel.add(view, identifier);
    }

    /**
     * Method that shows one card layout or another depending on the identifier.
     * @param identifier
     */

    public void setChangeView(String identifier){
        cardLayout.show(cardLayoutPanel, identifier);
    }

    /**
     * Method that shows the view on the screen
     */
    public void start() {
        setVisible(true);
    }

    /**
     * Method that defines the JPopUpMenu depending on the user entered.
     * The user has three options while the admin has only the option to log out.
     * @param user
     */
    public void defineSettings(boolean user) {

        menu = new JPopupMenu();
        if (user){
            // Popup settings menu
            menu.add(changePassword);
            menu.add(deleteAccount);
            menu.add(logout);
        }
        else{
            menu.add(logout);
        }
    }

    /**
     * Registers an ActionListener event handler for the SETTINGS and BACK_ARROW buttons
     * @param listener the ActionListener to register
     */
    public void registerController(ActionListener listener) {
        settingsButton.addActionListener(listener);
        homeButton.addActionListener(listener);
    }

    /**
     * Method that shows the Pop Up menu on the screen
     */
    public void showPopUpMenu() {

        menu.show(settingsButton, 0, settingsButton.getHeight());
    }

    /**
     * Registers an ActionListener event handler for the ITEMS in the settings menu
     * @param listener the ActionListener to register
     */
    public void registerSettings(ActionListener listener) {
        changePassword.addActionListener(listener);
        deleteAccount.addActionListener(listener);
        logout.addActionListener(listener);
    }

    /**
     * Method that updates the JTable given an arraylist of matches.
     * @param matchObjects
     */
    public void updateList(ArrayList<Match> matchObjects){
        model.setRowCount(0);

        for (Match match : matchObjects) {
            model.addRow(new Object[] { match.getTeam1(), match.getTeam1Score(), "VS", match.getTeam2Score(), match.getTeam2() });
        }

        table.setModel(model);
    }
}
