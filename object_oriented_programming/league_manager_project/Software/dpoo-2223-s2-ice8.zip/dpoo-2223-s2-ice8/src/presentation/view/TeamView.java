package presentation.view;

import business.entities.Team;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * View that shows a list of the Teams together with 2 buttons: CREATE TEAM and DELETE TEAM.
 */
public class TeamView extends JPanel{

    /**
     * View identifier
     */
    public static final String IDENTIFIER = "TeamView";

    private static ArrayList<String> teams = new ArrayList<>();

    private static JList<String> teamsList = new JList<>();

    //JButtons
    private JButton createButton;
    private JButton deleteButton;

    /**
     * Constructor
     */
    public TeamView() {
        configureView();
    }

    /**
     * Method that configures the view to display the teams panel
     * with labels, list, and buttons.
     */
    public void configureView() {

        // Create the nested Border layout for the center
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(Color.BLACK);
        centerPanel.setPreferredSize(new Dimension(1200, 700));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));

        // Add the JLabel to the north
        JLabel createTeamsLabel = new JLabel("Created Teams");
        //createTeamsLabel.setPreferredSize(new Dimension(0, 100));
        createTeamsLabel.setFont(new Font("Kreon", Font.BOLD, 60));
        createTeamsLabel.setForeground(Color.WHITE);
        centerPanel.add(createTeamsLabel, BorderLayout.NORTH);

        // Add the JList to the center

        teamsList = new JList<>(teams.toArray(new String[0]));
        JScrollPane scrollPane = new JScrollPane(teamsList);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        // Add the GridLayout with two buttons to the south
        JPanel buttonsPanel = new JPanel(new GridLayout(1, 2));
        buttonsPanel.setPreferredSize(new Dimension(0, 100));
        buttonsPanel.setBackground(Color.BLACK);
        createButton = new JButton("CREATE TEAM");
        deleteButton = new JButton("DELETE TEAM");
        createButton.setFont(new Font("Kreon", Font.PLAIN, 20));
        createButton.setOpaque(true);
        createButton.setBorderPainted(false);
        deleteButton.setOpaque(true);
        deleteButton.setBorderPainted(false);
        deleteButton.setFont(new Font("Kreon", Font.PLAIN, 20));
        createButton.setBackground(new Color(0, 255, 255)); // cian
        deleteButton.setBackground(new Color(255, 200, 100)); // orange

        createButton.setActionCommand("CREATE_TEAM_BUTTON");
        deleteButton.setActionCommand("DELETE_TEAM_BUTTON");
        buttonsPanel.add(createButton);
        buttonsPanel.add(deleteButton);
        centerPanel.add(buttonsPanel, BorderLayout.SOUTH);

        // Add the centerPanel to the center of the main BorderLayout
        add(centerPanel, BorderLayout.CENTER);

    }

    /**
     * Shows the view
     */
    public void start() {
        setVisible(true);
    }

    /**
     * Registers an ActionListener event handler for the CREATE_TEAM and DELETE_TEAM buttons
     * @param listener the ActionListener to register
     */
    public void registerController(ActionListener listener) {
        createButton.addActionListener(listener);
        deleteButton.addActionListener(listener);
    }

    /**
     * Updates the Team List given an arraylist of teams.
     * @param teamsObjects
     */
    public void updateTeamList(ArrayList<Team> teamsObjects){

        DefaultListModel<String> defaultListModel = new DefaultListModel<>();

        for (Team team : teamsObjects) {
            defaultListModel.addElement(team.getName());
        }

        teamsList.setModel(defaultListModel);

    }
}
