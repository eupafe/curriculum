package presentation.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * View that prompts the user to introduce the name of the league to be created. It also asks to input the date
 * and the time at which the league will take place.
 */
public class CreateLeagueView extends JPanel {

    /**
     * View identifier
     */
    public static final String IDENTIFIER = "CreateLeagueView";

    // JTextField
    private static JTextField nameTextField;
    // JButton
    private JButton createButton;
    private JComboBox<Integer> combo1;
    private JComboBox<Integer> combo2;
    private JComboBox<Integer> combo3;
    private JComboBox<Integer> combo4;
    private JComboBox<Integer> combo5;

    private int day = 0;
    private int month = 0;
    private int year = 0;
    private int hour = 0;
    private int minutes = 0;

    /**
     * Constructor
     */
    public CreateLeagueView() {
        configureView();
    }

    /**
     * Method that configures the view with a GridPanel containing the name, date time settings and one JButton.
     */
    private void configureView() {

        setBackground(Color.BLACK);
        //setBorder(BorderFactory.createEmptyBorder(10, 100, 10, 100));

        JPanel panel = createGridPanel();
        add(panel);
    }

    /**
     * Creates and returns a JPanel with a grid layout for arranging multiple sub-panels vertically.
     * @return JPanel with grid layout
     */

    private JPanel createGridPanel(){
        JPanel gridPanel = new JPanel(new GridBagLayout());
        gridPanel.setBackground(Color.BLACK);
        //gridPanel.setPreferredSize(new Dimension(1400, 1050));
        gridPanel.setLayout(new BoxLayout(gridPanel, BoxLayout.PAGE_AXIS));

        GridBagConstraints c = new GridBagConstraints();

        JPanel panel1 = createNameSettings();

        JPanel panel2 = createDateTimeSettings();

        JPanel panel3 = createContinueSettings();

        c.gridx = 0;
        c.gridy = 0;
        c.gridheight = 1;
        c.weighty = 1.0;
        c.fill = GridBagConstraints.BOTH;
        gridPanel.add(panel1, c);

        c.gridx = 0;
        c.gridy = 1;
        c.gridheight = 1;
        c.weighty = 1.0;
        c.fill = GridBagConstraints.BOTH;
        gridPanel.add(panel2, c);

        c.gridx = 0;
        c.gridy = 2;
        c.weighty = 1.0;
        c.fill = GridBagConstraints.BOTH;
        gridPanel.add(panel3, c);

        return gridPanel;
    }

    /**
     * Creates and returns a JPanel for the name settings section.
     * The panel includes a JLabel, a text field for entering the league's name,
     * and event listeners to handle focus events and default texts.
     * @return JPanel with all the name settings
     */
    private JPanel createNameSettings(){

        JPanel panel2 = new JPanel();
        panel2.setBackground(Color.BLACK);
        panel2.setLayout(new BoxLayout(panel2, BoxLayout.Y_AXIS));
        panel2.setPreferredSize(new Dimension(400, 166));

        JLabel usernameLabel = new JLabel("Name");
        usernameLabel.setFont(new Font("Inter", Font.BOLD, 20));
        usernameLabel.setForeground(Color.WHITE);
        Component verticalSpacer1 = Box.createRigidArea(new Dimension(0, 7));
        Component verticalSpacer2 = Box.createRigidArea(new Dimension(0, 7));
        nameTextField = new JTextField("Type the league's name");
        nameTextField.setFont(new Font("Inter", Font.BOLD, 12));

        nameTextField.addFocusListener(new FocusAdapter() {

            @Override
            public void focusGained(FocusEvent e) {
                if (nameTextField.getText().equals("Type the league's name")) {
                    nameTextField.setText("");
                }
            }
            @Override
            public void focusLost(FocusEvent e) {
                if (nameTextField.getText().equals("")) {
                    nameTextField.setText("Type the league's name");
                }
            }
        });

        panel2.add(verticalSpacer1);
        panel2.add(usernameLabel);
        panel2.add(verticalSpacer2);
        panel2.setBorder(BorderFactory.createEmptyBorder(35, 0, 30, 0));
        //panel2.setBorder(BorderFactory.createEmptyBorder(35, 40, 30, 40));
        panel2.add(nameTextField);

        return panel2;
    }

    /**
     * Creates and returns a JPanel for the date and time settings. It includes two sub-panels:
     * one for selecting the date and one for selecting the time.
     * Each sub-panel contains labels and combo boxes for choosing the desired date and time.
     * @return JPanel with the date and time settings.
     */
    private JPanel createDateTimeSettings(){

        JPanel containerPanel = new JPanel(new GridLayout(1, 2));
        containerPanel.setPreferredSize(new Dimension(400, 166));
        containerPanel.setBackground(Color.BLACK);
        JPanel datePanel = new JPanel(new BorderLayout());
        datePanel.setBackground(Color.BLACK);

        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setForeground(Color.WHITE);
        dateLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        datePanel.add(dateLabel, BorderLayout.NORTH);

        JPanel spinnerPanel = new JPanel();
        spinnerPanel.setBackground(Color.BLACK);
        spinnerPanel.setLayout(new BoxLayout(spinnerPanel, BoxLayout.X_AXIS));
        spinnerPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 5, 5));

        DefaultComboBoxModel<Integer> days = new DefaultComboBoxModel<>();
        for (int i = 1; i <= 30; i++) {
            days.addElement(i);
        }
        combo1 = new JComboBox<>(days);
        combo1.setActionCommand("COMBO_DAY");

        DefaultComboBoxModel<Integer> month = new DefaultComboBoxModel<>();
        for (int i = 1; i <= 12; i++) {
            month.addElement(i);
        }
        combo2 = new JComboBox<>(month);
        combo2.setActionCommand("COMBO_MONTH");

        DefaultComboBoxModel<Integer> year = new DefaultComboBoxModel<>();
        for (int i = 2023; i <= 2035; i++) {
            year.addElement(i);
        }
        combo3 = new JComboBox<>(year);
        combo3.setActionCommand("COMBO_YEAR");

        spinnerPanel.add(combo1);
        spinnerPanel.add(combo2);
        spinnerPanel.add(combo3);

        datePanel.add(spinnerPanel, BorderLayout.CENTER);

        JPanel timePanel = new JPanel(new BorderLayout());
        timePanel.setBackground(Color.BLACK);

        JLabel timeLabel = new JLabel("Time:");
        timeLabel.setForeground(Color.WHITE);
        timeLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        timePanel.add(timeLabel, BorderLayout.NORTH);

        JPanel timeInputPanel = new JPanel();
        timeInputPanel.setBackground(Color.BLACK);
        timeInputPanel.setLayout(new BoxLayout(timeInputPanel, BoxLayout.X_AXIS));
        timeInputPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 5, 5));

        DefaultComboBoxModel<Integer> hours = new DefaultComboBoxModel<>();
        for (int i = 0; i <= 23; i++) {
            hours.addElement(i);
        }
        combo4 = new JComboBox<>(hours);
        combo4.setActionCommand("COMBO_HOURS");

        DefaultComboBoxModel<Integer> minutes = new DefaultComboBoxModel<>();
        for (int i = 0; i <= 59; i++) {
            minutes.addElement(i);
        }
        combo5 = new JComboBox<>(minutes);
        combo5.setActionCommand("COMBO_MINUTES");

        timeInputPanel.add(combo4);
        timeInputPanel.add(combo5);

        timePanel.add(timeInputPanel, BorderLayout.CENTER);

        containerPanel.add(datePanel);
        containerPanel.add(timePanel);

        return containerPanel;
    }

    /**
     * Function that creates a JButton.
     * @return JPanel that contains the button.
     */
    private JPanel createContinueSettings(){

        JPanel panel3 =  new JPanel();
        panel3.setBackground(Color.BLACK);
        panel3.setPreferredSize(new Dimension(400, 166));

        createButton = new JButton("Add Teams");
        createButton.setFont(new Font("Kreon", Font.BOLD, 15));
        createButton.setBackground(Color.WHITE);
        createButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        createButton.setAlignmentY(Component.CENTER_ALIGNMENT);
        createButton.setActionCommand("ADD_TEAMS");

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;

        panel3.setLayout(new GridBagLayout());
        panel3.add(createButton, gbc);


        return panel3;
    }

    /**
     * Shows the view
     */
    public void start() {
        setVisible(true);
    }

    /**
     * Method that gets the name entered.
     * @return String name
     */

    public String getName() {
        return nameTextField.getText();
    }

    /**
     * Method that returns the LocalDate entered by the user.
     * @return LocalDate of the date entered
     */
    public LocalDate getStartDate() {
        return LocalDate.of(year, month, day);
    }

    /**
     * Function that returns the LocalTime entered by the user.
     * @return LocalTime of the time entered
     */

    public LocalTime getStartTime() {
        return LocalTime.of(hour, minutes);
    }

    /**
     * Method that gets the day selected in the first combo box.
     * @return int of the day
     */
    public int getDay() {
        return (int) combo1.getSelectedItem();
    }

    /**
     * Method that gets the month selected in the second combo box.
     * @return int of the month
     */

    public int getMonth() {
        return (int) combo2.getSelectedItem();
    }

    /**
     * Method that gets the year selected in the third combo box.
     * @return int of the year
     */
    public int getYear() {
        return (int) combo3.getSelectedItem();
    }

    /**
     * Method that gets the hour in the fourth combo box.
     * @return int of the hour
     */
    public int getHour() {
        return (int) combo4.getSelectedItem();
    }

    /**
     * Method that gets the minutes in the fifth combo box.
     * @return int of the minutes
     */
    public int getMinutes() {
        return (int) combo5.getSelectedItem();
    }

    /**
     * Method that sets the day given an int in the first combo box.
     * @param day
     */
    public void setDay(int day) {
        this.day = day;
    }

    /**
     * Method that sets the month given an int in the second combo box.
     * @param month
     */
    public void setMonth(int month) {
        this.month = month;
    }

    /**
     * Method that sets the year given an int in the third combo box.
     * @param year
     */
    public void setYear(int year) {
        this.year = year;
    }
    /**
     * Method that sets the hour given an int in the fourth combo box.
     * @param hour
     */

    public void setHour(int hour) {
        this.hour = hour;
    }

    /**
     * Method that sets the minutes given an int in the fifth combo box.
     * @param minutes
     */
    public void setMinutes(int minutes) {
        this.minutes = minutes;
    }

    /**
     * Method that resets the textfield to an empty string.
     */
    public void reset(){
        nameTextField.setText("");
    }

    /**
     * Function that resets all the combo boxes to the first item from the selected items.
     */

    public void resetComboBox(){
        combo1.setSelectedIndex(0);
        combo2.setSelectedIndex(0);
        combo3.setSelectedIndex(0);
        combo4.setSelectedIndex(0);
        combo5.setSelectedIndex(0);

    }

    /**
     * Registers the ActionListener given to listen for events from the create Button and combo boxes.
     * @param listener
     */

    public void registerController(ActionListener listener) {
        createButton.addActionListener(listener);
        combo1.addActionListener(listener);
        combo2.addActionListener(listener);
        combo3.addActionListener(listener);
        combo4.addActionListener(listener);
        combo5.addActionListener(listener);
    }

}