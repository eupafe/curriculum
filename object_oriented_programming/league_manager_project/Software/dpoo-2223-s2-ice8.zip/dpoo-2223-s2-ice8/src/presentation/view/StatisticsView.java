package presentation.view;
import business.entities.Statistics;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * View that shows a chart representing all the statistics.
 */
public class StatisticsView extends JPanel {

    /**
     * View identifier
     */
    public static final String IDENTIFIER = "StatisticsView";

    private String[] teamNames;

    private ArrayList<Statistics> statistics;

    /**
     * Constructor
     */
    public StatisticsView() {
        setLayout(new BorderLayout());
        configureView();
        statistics = new ArrayList<>();
    }

    /**
     * Generates and stores data from the given list of statistics.
     * @param statistics the list of statistics containing team information and points
     */
    //This will be deleted when we get the data from the DataBase
    private void generateData(ArrayList<Statistics> statistics) {
        this.statistics = statistics;
        teamNames = new String[statistics.size()];

        for (int i = 0; i < statistics.size(); i++) {
            teamNames[i] = statistics.get(i).getTeamName();
        }
    }

    /**
     * Configures the view for displaying a graph.
     * Overrides the paintComponent method to draw the graph with proper lines.
     */
    public void configureView(){
        // CREATE GRAPHIC PANEL
        JPanel mainPanel = new JPanel() {
            /**
             * Functions that draws the graphic itself with the proper lines
             *
             * @param g the Graphics object to paint on
             */
            @Override
            public void paintComponent(Graphics g) {

                super.paintComponent(g);


                int width = getWidth();
                int height = getHeight();
                int padding = 50;
                int graphWidth = width - 2 * padding;
                int graphHeight = height - 2 * padding;

                // Draw x and y axes
                g.drawLine(padding, height - padding, padding, padding);
                g.drawLine(padding, height - padding, width - padding, height - padding);

                // Draw x and y labels
                g.setFont(new Font("Arial", Font.BOLD, 12));
                g.drawString("Match Day", width - padding - 20, height - padding + 20);
                g.drawString("Points", padding - 20, padding - 10);

                // Draw the x axis values
                g.setFont(new Font("Arial", Font.PLAIN, 10));
                int numTicksX = 10;
                int xTickSpacing = graphWidth / numTicksX;
                int xValue = 0;
                for (int i = 0; i <= numTicksX; i++) {
                    int x = padding + (i * xTickSpacing);
                    int y = height - padding + 12;
                    g.drawString(Integer.toString(xValue), x, y);
                    xValue++;
                }

                // Draw the y axis values
                int numTicksY = 10;
                int yTickSpacing = graphHeight / numTicksY;
                int yValue = 0;
                for (int i = 0; i <= numTicksY; i++) {
                    int x = padding - 40;
                    int y = height - padding - (i * yTickSpacing);
                    g.drawString(Integer.toString(yValue), x, y);
                    yValue++;
                }

                // Draw the lines
                Color[] colors = {Color.BLUE, Color.RED, Color.GREEN, Color.ORANGE, Color.MAGENTA};
                int colorIndex = 0;


                for (Statistics statistic : statistics) {
                    g.setColor(colors[colorIndex % colors.length]);

                    int startX = padding;
                    int startY = height - padding;

                    for (int i = 0; i < statistic.getPoints().size(); i ++) {
                        int x = padding + (int) ((i + 1) * graphWidth/10);
                        int y = height - padding - (int) (statistic.getPoints().get(i) * graphHeight/10);

                        g.drawLine(startX, startY, x, y);
                        startX = x;
                        startY = y;
                    }

                    // Draw the legend
                    int legendX = width - padding - 80;
                    int legendY = padding + 20 + colorIndex * 20;
                    g.drawString(statistic.getTeamName(), legendX, legendY);

                    colorIndex++;
                }
            }

        };
        // ADD THE PANELS TO THE MAIN ONE
        add(mainPanel, BorderLayout.CENTER);

    }

    /**
     * Updates the graph with new data.
     */
    public void updateGraph(ArrayList<Statistics> statistics) {
        generateData(statistics);
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                repaint(); // Redraw the graph with the updated data
            }
        });
        //repaint(); // Redraw the graph with the updated data
    }
}

