package presentation.view;

import business.entities.League;
import presentation.controller.LeagueController;

import javax.swing.*;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * View that shows the admin a list of the created leagues. It has 2 buttons: CREATE LEAGUE and DELETE LEAGUE.
 */
public class LeagueView extends JPanel{

    /**
     * View identifier
     */
    public static final String IDENTIFIER = "LeagueView";

    private static ArrayList<String> leagues = new ArrayList<>();

    private static JList<String> leaguesList = new JList<>();

    //JButtons
    private JButton createButton;
    private JButton deleteButton;
    private static DefaultTableModel model;
    private static JTable table;


    /**
     * Constructor
     */
    public LeagueView() {
        configureView();
    }

    /**
     * This method configures the view by setting up the layout, borders,
     * JLabel, a JTable with league information, and buttons for creating and deleting leagues.
     */
    private void configureView() {

        // Create the nested Border layout for the center
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(Color.BLACK);
        centerPanel.setPreferredSize(new Dimension(1200, 700));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));

        // Add the JLabel to the north
        JLabel createTeamsLabel = new JLabel("Created Leagues");
        //createTeamsLabel.setPreferredSize(new Dimension(0, 100));
        createTeamsLabel.setFont(new Font("Kreon", Font.BOLD, 60));
        createTeamsLabel.setForeground(Color.WHITE);
        centerPanel.add(createTeamsLabel, BorderLayout.NORTH);

        // Add the JList to the center

        // Create the DefaultTableModel with the data and column names
        model = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Disable cell editing for all cells
                return false;
            }
        };

        model.addColumn("LEAGUE NAME");
        model.addColumn("STATUS");
        model.addColumn("# TEAMS");

        table = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(table);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        // Add the GridLayout with two buttons to the south
        JPanel buttonsPanel = new JPanel(new GridLayout(1, 2));
        buttonsPanel.setPreferredSize(new Dimension(0, 100));
        buttonsPanel.setBackground(Color.BLACK);
        createButton = new JButton("CREATE LEAGUE");
        deleteButton = new JButton("DELETE LEAGUE");
        createButton.setFont(new Font("Kreon", Font.PLAIN, 20));
        createButton.setOpaque(true);
        createButton.setBorderPainted(false);
        deleteButton.setOpaque(true);
        deleteButton.setBorderPainted(false);
        deleteButton.setFont(new Font("Kreon", Font.PLAIN, 20));
        createButton.setBackground(new Color(0, 255, 255)); // cian
        deleteButton.setBackground(new Color(255, 200, 100)); // orange

        createButton.setActionCommand("CREATE_LEAGUE_BUTTON");
        deleteButton.setActionCommand("DELETE_LEAGUE_BUTTON");

        buttonsPanel.add(createButton);
        buttonsPanel.add(deleteButton);
        centerPanel.add(buttonsPanel, BorderLayout.SOUTH);

        // Add the centerPanel to the center of the main BorderLayout
        add(centerPanel, BorderLayout.CENTER);

    }

    /**
     * Method that shows the view
     */
    public void start() {
        setVisible(true);
    }

    /**
     * Registers an ActionListener event handler for the CREATE_LEAGUE and DELETE_LEAGUE buttons
     * //@param listener the ActionListener to register
     */
    public void registerController(LeagueController leagueController) {
        createButton.addActionListener(leagueController::actionPerformed);
        deleteButton.addActionListener(leagueController::actionPerformed);
        table.addMouseListener(leagueController);
    }

    /**
     * Function that returns the JList of the view
     * @return Jlist
     */
    public JList<String> getList() {
        return leaguesList;
    }

    /**
     * Method that updates the league JTable given an arraylist of leagues, strings and integers.
     * @param leagueObjects
     * @param status
     * @param numTeams
     */
    public void updateLeagueList(ArrayList<League> leagueObjects, ArrayList<String> status, ArrayList<Integer> numTeams){

        model.setRowCount(0);

        for (int i = 0; i < leagueObjects.size(); i++) {
            model.addRow(new Object[] { leagueObjects.get(i).getName(), status.get(i), numTeams.get(i) });
        }
        table.setModel(model);
    }


    /**
     * Method that returns the JTable of the view.
     * @return
     */
    public JTable getTable() {
        return table;
    }

}

