package presentation.controller;

import business.LeagueManager;
import business.MatchManager;
import business.TeamManager;
import business.UserManager;
import business.entities.Match;
import business.entities.User;
import presentation.view.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


/**
 * The MainController class handles the actions and events mainly related to the change of the card layout.
 * It implements the ActionListener and MouseListener interface.
 */

public class MainController implements ActionListener, MouseListener {

    // VIEWS
    private final MainWindow mainWindow;
    private final LogInView loginView;
    private final BaseView baseView;
    private final AdminMainView adminMainView;
    private final TeamView teamView;
    private final LeagueView leagueView;
    private final CreateLeagueView createLeagueView;
    private final AddTeamsToLeagueView addTeamsToLeagueView;
    private final DeleteLeagueView deleteLeagueView;
    private final DeleteTeamView deleteTeamView;
    private final StatisticsView statisticsView;
    private final CreatedPlayersView createdPlayersView;
    private final PlayerMainView playerMainView;
    private final ListTeamsView listTeamsView;
    private final ListPlayersView listPlayersView;

    // MANAGERS
    private final UserManager userManager;
    private final LeagueManager leagueManager;
    private final TeamManager teamManager;
    private final MatchManager matchManager;

    // CONTROLLERS
    private final LogInController logInController;
    private final LeagueController leagueController;
    private final TeamController teamController;

    // POP-UPS
    private JLabel successLabel;

    private String leagueDisplayed;

    /**
     * Constructor
     */
    public MainController(MainWindow mainWindow, LogInView logInView, BaseView baseView, AdminMainView adminMainView,
                          TeamView teamView, LeagueView leagueView, CreateLeagueView createLeagueView, AddTeamsToLeagueView addTeamsToLeagueView,
                          DeleteLeagueView deleteLeagueView, DeleteTeamView deleteTeamView, StatisticsView statisticsView, CreatedPlayersView createdPlayersView,
                          PlayerMainView playerMainView, ListTeamsView listTeamsView, ListPlayersView listPlayersView, UserManager userManager, LeagueManager leagueManager, TeamManager teamManager, LogInController logInController, LeagueController leagueController,
                          TeamController teamController, MatchManager matchManager) {

        this.baseView = baseView;
        this.mainWindow = mainWindow;

        this.loginView = logInView;
        this.adminMainView = adminMainView;
        this.teamView = teamView;
        this.leagueView = leagueView;
        this.createLeagueView = createLeagueView;
        this.addTeamsToLeagueView = addTeamsToLeagueView;
        this.deleteLeagueView = deleteLeagueView;
        this.deleteTeamView = deleteTeamView;
        this.statisticsView = statisticsView;
        this.createdPlayersView = createdPlayersView;
        this.playerMainView = playerMainView;
        this.listPlayersView = listPlayersView;
        this.listTeamsView = listTeamsView;
        //

        this.userManager = userManager;
        this.leagueManager = leagueManager;
        this.teamManager = teamManager;
        this.matchManager = matchManager;

        this.logInController = logInController;
        this.leagueController = leagueController;
        this.teamController = teamController;

        baseView.registerController(this);
        adminMainView.registerController(this);
        logInView.registerController(this);
        logInController.registerMainController(this);

        setMainCardLayout();
        setCardLayout();
    }

    /**
     * Set card layout
     */
    public void setCardLayout() {
        baseView.addToCardLayout(AdminMainView.IDENTIFIER, adminMainView);
        baseView.addToCardLayout(TeamView.IDENTIFIER, teamView);
        baseView.addToCardLayout(LeagueView.IDENTIFIER, leagueView);
        baseView.addToCardLayout(CreateLeagueView.IDENTIFIER, createLeagueView);
        baseView.addToCardLayout(AddTeamsToLeagueView.IDENTIFIER, addTeamsToLeagueView);
        baseView.addToCardLayout(DeleteLeagueView.IDENTIFIER, deleteLeagueView);
        baseView.addToCardLayout(DeleteTeamView.IDENTIFIER, deleteTeamView);
        baseView.addToCardLayout(StatisticsView.IDENTIFIER, statisticsView);
        baseView.addToCardLayout(CreatedPlayersView.IDENTIFIER, createdPlayersView);
        baseView.addToCardLayout(PlayerMainView.IDENTIFIER, playerMainView);
        baseView.addToCardLayout(ListTeamsView.IDENTIFIER, listTeamsView);
        baseView.addToCardLayout(ListPlayersView.IDENTIFIER, listPlayersView);

    }

    /**
     * Set main card layout for loginView and BaseView
     */
    public void setMainCardLayout(){
        mainWindow.addToCardLayout(LogInView.IDENTIFIER, loginView);
        mainWindow.addToCardLayout(BaseView.IDENTIFIER, baseView);
    }

    /**
     * Method that defines the BaseView depending on the user entered.
     */
    public void defineBaseView(){
        boolean user = false;

        matchManager.startMatchSimulator();

        if (userManager.isUser()){
            playerMainView.updateLeagueList(leagueManager.getLeagues(userManager.getUser()), leagueManager.getLeaguesStatus(userManager.getUser()),
                                            leagueManager.getLeaguesNumberTeams(userManager.getUser()));
            playerMainView.registerController(this);
            baseView.setChangeView(PlayerMainView.IDENTIFIER);
            user = true;
        }
        else{
            baseView.setChangeView(AdminMainView.IDENTIFIER);
        }
        baseView.defineSettings(user);
        setChangeView(BaseView.IDENTIFIER);
    }

    /**
     * Override function that receives an event and acts accordingly.
     * @param e the event to be processed
     */
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getActionCommand().equals("TEAMS_BUTTON")) {
            teamView.updateTeamList(teamManager.getAllTeams()); // Update the list of teamsView
            baseView.setChangeView(TeamView.IDENTIFIER);
            teamView.registerController(teamController);
        } else if (e.getActionCommand().equals("LEAGUES_BUTTON")) {
            User user = userManager.getUser();
            leagueView.updateLeagueList(leagueManager.getLeagues(user), leagueManager.getLeaguesStatus(user), leagueManager.getLeaguesNumberTeams(user)); // Update the list of LeaguesView
            baseView.setChangeView(LeagueView.IDENTIFIER);
            leagueView.registerController(leagueController);
        } else if (e.getActionCommand().equals("HOME_BUTTON")) {

            if (userManager.isUser()) {

                baseView.setChangeView(PlayerMainView.IDENTIFIER);
            } else {

                baseView.setChangeView(AdminMainView.IDENTIFIER);
            }

        } else if (e.getActionCommand().equals("SETTINGS_BUTTON")) {
            baseView.showPopUpMenu();
            baseView.registerSettings(this);
        } else if (e.getActionCommand().equals("CHANGE_PASSWORD")) {
            showChangePasswordDialog();
        } else if (e.getActionCommand().equals("DELETE_ACCOUNT")) {
            userManager.deleteUser();
            userManager.logOut();
            logInController.reset();
            setChangeView(LogInView.IDENTIFIER);
        } else if (e.getActionCommand().equals("LOG_OUT")) {
            userManager.logOut();
            logInController.reset();
            setChangeView(LogInView.IDENTIFIER);

        } else if (e.getActionCommand().equals("LOG_IN")) {
            logInController.checkLogin();
        } else if (e.getActionCommand().equals("GO_BACK_BUTTON")) {
            baseView.setChangeView(ListTeamsView.IDENTIFIER);

        } else if (e.getActionCommand().equals("SHOW_STATS_BUTTON")) {
            statisticsView.updateGraph(leagueManager.getStatisticsByLeague(leagueDisplayed));
            baseView.setChangeView(StatisticsView.IDENTIFIER);

        }
    }

    /**
     * Updates the simulation with the given list of matches.
     * @param matches The list of matches to update.
     */

    public void updateSimulation(ArrayList<Match> matches){

        baseView.updateList(matches);

        if(userManager.isUser()){
            listTeamsView.updateTeamList(leagueManager.getTeamsByLeague(leagueDisplayed), leagueManager.getTeamsWonGames(leagueDisplayed),
                    leagueManager.getTeamsLostGames(leagueDisplayed), leagueManager.getTeamsTiedGames(leagueDisplayed),
                    leagueManager.getTeamsNumberPlayers(leagueDisplayed));
            User user = userManager.getUser();
            leagueView.updateLeagueList(leagueManager.getLeagues(user), leagueManager.getLeaguesStatus(user), leagueManager.getLeaguesNumberTeams(user));
        } else {
            leagueController.updateData();

        }
    }

    /**
     * Updates statistics depending on the user that has entered the program.
     */
    public void updateStatistics(){
        if(userManager.isUser()) {
            statisticsView.updateGraph(leagueManager.getStatisticsByLeague(leagueDisplayed));
        } else{
            leagueController.updateStatistics();
        }
    }

    /**
     * Start the application
     */

    public void start() {
        mainWindow.setChangeView(LogInView.IDENTIFIER);
        mainWindow.start();
    }

    /**
     * Method that calls the main window to change its card layout. Receives the identifier
     * of the view to which it needs to change.
     * @param identifier
     */
    public void setChangeView(String identifier) {
        mainWindow.setChangeView(identifier);
    }

    /**
     * Shows a JDialog that allows to the enter the stored password and the new one.
     * It also handles errors that could happen.
     */
    public void showChangePasswordDialog() {

        JDialog dialog = new JDialog(mainWindow, "Change Password", true);
        JPasswordField passwordField1 = new JPasswordField(20);
        JPasswordField passwordField2 = new JPasswordField(20);

        JButton confirmButton = new JButton("OK");
        confirmButton.addActionListener(e -> {

            String password1 = new String(passwordField1.getPassword());
            String password2 = new String(passwordField2.getPassword());

            if (password1.equals(userManager.getPassword())) {

                if (userManager.checkPassword(password2)) {
                    userManager.updatePassword(password2);
                    successLabel.setText("Password successfully changed!");
                    confirmButton.setEnabled(false);
                }
                else{
                    successLabel.setText("<html><div style='text-align: center;'>Password must be at least 8 characters<br>long and contain lowercase,<br>uppercase, and numbers.</div></html>");
                }
            } else {
                successLabel.setText("Passwords not found. Please try again.");
                confirmButton.setEnabled(true);
            }
        });

        JPanel panel = new JPanel();
        panel.add(new JLabel("Enter current password:"));
        panel.add(passwordField1);
        panel.add(new JLabel("Enter new password:"));
        panel.add(passwordField2);
        panel.add(confirmButton);
        successLabel = new JLabel();
        panel.add(successLabel);

        dialog.getContentPane().add(panel);

        dialog.setSize(250, 300);
        dialog.setLocationRelativeTo(mainWindow);
        dialog.setVisible(true);
    }

    /**
     * It receives an event and acts accordingly depending on the JTable clicked.
     * @param e the event to be processed
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        JTable table = (JTable) e.getSource();
        int row = table.rowAtPoint(e.getPoint());
        int column = table.columnAtPoint(e.getPoint());

        if(e.getSource() == playerMainView.getTable()){

            if (row >= 0 && column >= 0) {
                this.leagueDisplayed = (String) table.getValueAt(row, 0);
                listTeamsView.updateTeamList(leagueManager.getTeamsByLeague(leagueDisplayed), leagueManager.getTeamsWonGames(leagueDisplayed),
                        leagueManager.getTeamsLostGames(leagueDisplayed), leagueManager.getTeamsTiedGames(leagueDisplayed), leagueManager.getTeamsNumberPlayers(leagueDisplayed));
                listTeamsView.setLeagueLabel(leagueDisplayed);
                listTeamsView.registerController(this::actionPerformed, this);
                baseView.setChangeView(ListTeamsView.IDENTIFIER);
            }

        }else if (e.getSource() == listTeamsView.getTable()){

            if (row >= 0 && column >= 0) {
                Object team = table.getValueAt(row, 0);
                listPlayersView.updatePlayerList(teamManager.getPlayersByTeam((String) team));
                listPlayersView.setLeagueLabel((String) team);
                listPlayersView.registerController(this::actionPerformed);
                baseView.setChangeView(ListPlayersView.IDENTIFIER);
            }
        }
    }

    /**
     * Method not used.
     * @param e the event to be processed
     */
    @Override
    public void mousePressed(MouseEvent e) {

    }

    /**
     * Method not used.
     * @param e the event to be processed
     */
    @Override
    public void mouseReleased(MouseEvent e) {

    }

    /**
     * Method not used.
     * @param e the event to be processed
     */
    @Override
    public void mouseEntered(MouseEvent e) {

    }

    /**
     * Method not used.
     * @param e the event to be processed
     */
    @Override
    public void mouseExited(MouseEvent e) {

    }


}