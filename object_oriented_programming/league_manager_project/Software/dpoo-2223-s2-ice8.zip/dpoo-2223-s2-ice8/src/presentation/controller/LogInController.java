package presentation.controller;

import business.UserManager;
import presentation.view.LogInView;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

/**
 * The Log In Controller class handles the actions and events related to the Log In view.
 */
public class LogInController{

    // VIEWS
    private final LogInView logInView;

    // MANAGERS
    private final UserManager userManager;

    // CONTROLLERS
    private MainController mainController;

    /**
     * Constructor
     */
    public LogInController(LogInView logInView, UserManager userManager) {

        this.logInView =  logInView;
        this.userManager = userManager;
        this.mainController = null;
    }

    /**
     * Function that sets the main controller.
     * @param mainController
     */
    public void registerMainController(MainController mainController){
        this.mainController = mainController;
    }

    /**
     * Method that talks with user manager and the view to check whether the login is valid or not.
     */
    public void checkLogin(){
        String user = logInView.getUsername();
        String password = logInView.getPassword();

        if (userManager.loginIsValid(user, password)){
            logInView.setLoginFieldsBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
            logInView.setMessageLabelText("", Color.BLACK);
            userManager.setUser(user);
            mainController.defineBaseView();
            //mainController.setChangeView("BaseView");
        }
        else{
            Border redBorder = BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(Color.red, 2),
                    BorderFactory.createEmptyBorder(1, 1, 1, 1));
            logInView.setLoginFieldsBorder(redBorder);
            logInView.setMessageLabelText("Incorrect credentials. Please, try again", Color.red);
        }
    }

    /**
     * Method that resets the log in view.
     */
    public void reset() {
        logInView.reset();
    }
}