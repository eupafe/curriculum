package presentation.controller;

import business.MatchManager;
import business.TeamManager;
import business.UserManager;
import business.entities.User;
import presentation.view.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

/**
 * The TeamController class handles the actions and events related to team operations.
 * It implements the ActionListener interface.
 */
public class TeamController implements ActionListener {

    //VIEWS
    private final TeamView teamView;
    private final BaseView baseView;
    private final DeleteTeamView deleteTeamView;
    private final CreatedPlayersView createdPlayersView;

    // MANAGERS
    private final TeamManager teamManager;
    private final UserManager userManager;

    private final MatchManager matchManager;

    private JFileChooser fileChooser;

    /**
     * Constructor that receives the different views and managers related to teams.
     * @param baseView
     * @param teamView
     * @param deleteTeamView
     * @param createdPlayersView
     * @param teamManager
     * @param userManager
     * @param matchManager
     */
    public TeamController(BaseView baseView, TeamView teamView, DeleteTeamView deleteTeamView, CreatedPlayersView createdPlayersView,
                          TeamManager teamManager, UserManager userManager, MatchManager matchManager) {

        this.teamView = teamView;
        this.baseView = baseView;
        this.deleteTeamView = deleteTeamView;
        this.createdPlayersView = createdPlayersView;

        this.teamManager = teamManager;
        this.userManager = userManager;
        this.matchManager = matchManager;

        teamView.registerController(this);
    }

    /**
     * Function that receives the event to be process, and acts depending on it.
     * @param e the event to be processed
     */
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getActionCommand().equals("CREATE_TEAM_BUTTON")){
            fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(teamView);
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                String filePath = selectedFile.getAbsolutePath();
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        fileChooser.cancelSelection();
                    }
                });

                int error = teamManager.validateTeam(filePath);

                if(error == 1){
                    // Team name already exists
                    JOptionPane.showMessageDialog(teamView, "Team name already exists", "Error", JOptionPane.ERROR_MESSAGE);
                } else if(error == 2){
                    // any players email is incorrectly formatted
                    JOptionPane.showMessageDialog(teamView, "Player email incorrectly formatted", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (error == 3){
                    // any players squad number is not positive integer or 0
                    JOptionPane.showMessageDialog(teamView, "Player squad name must be >= 0", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (error == 4){
                    // any players DNI is incorrectly formatted
                    JOptionPane.showMessageDialog(teamView, "Player DNI incorrectly formatted", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (error == 0){
                    ArrayList<User> users = userManager.createMissingPlayers(filePath);
                    boolean success = teamManager.createTeam(filePath);

                    if (success) {
                        createdPlayersView.updateList(users); // Update the list of teamsView
                        baseView.setChangeView(CreatedPlayersView.IDENTIFIER);
                    }
                }
            }

        } else if(e.getActionCommand().equals("DELETE_TEAM_BUTTON")){
            deleteTeamView.updateTeamList(teamManager.getAllTeams());
            baseView.setChangeView(DeleteTeamView.IDENTIFIER);
            deleteTeamView.registerController(this);

        } else if(e.getActionCommand().equals("FINAL_DELETE_TEAM")){

            ArrayList<String> teamsToDelete = deleteTeamView.getCheckBoxes();
            for (int i = 0; i < teamsToDelete.size(); i++) {
                matchManager.forceCloseMatchesByTeam(teamsToDelete.get(i));
            }
            teamManager.deleteTeams(teamsToDelete);
            teamView.updateTeamList(teamManager.getAllTeams()); // Update the list of teamsView
            baseView.setChangeView(TeamView.IDENTIFIER);
            teamView.registerController(this);

        }

    }
}
