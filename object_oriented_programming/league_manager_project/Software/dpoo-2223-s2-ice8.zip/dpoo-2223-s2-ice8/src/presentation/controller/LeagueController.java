package presentation.controller;

import business.LeagueManager;
import business.MatchManager;
import business.TeamManager;
import business.UserManager;
import business.entities.User;
import presentation.view.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

/**
 * League Controller handles the actions and events related to league operations.
 * It implements the ActionListener and MouseListener interface.
 */
public class LeagueController implements ActionListener, MouseListener {

    // VIEWS
    private final LeagueView leagueView;
    private final BaseView baseView;
    private final CreateLeagueView createLeagueView;
    private final AddTeamsToLeagueView addTeamsToLeagueView;
    private final DeleteLeagueView deleteLeagueView;
    private final ListTeamsView listTeamsView;
    private final ListPlayersView listPlayersView;
    private final StatisticsView statisticsView;

    // MANAGERS
    private final LeagueManager leagueManager;
    private final TeamManager teamManager;
    private final UserManager userManager;

    private final MatchManager matchManager;

    private String leagueDisplayed;

    /**
     * Constructor
     */
    public LeagueController(BaseView baseView, LeagueView leagueView, CreateLeagueView createLeagueView,
                            AddTeamsToLeagueView addTeamsToLeagueView, DeleteLeagueView deleteLeagueView, ListTeamsView listTeamsView,
                            ListPlayersView listPlayersView, StatisticsView statisticsView,
                            TeamManager teamManager, LeagueManager leagueManager, UserManager userManager,MatchManager matchManager) {
        this.baseView = baseView;
        this.leagueView = leagueView;
        this.createLeagueView = createLeagueView;
        this.addTeamsToLeagueView = addTeamsToLeagueView;
        this.deleteLeagueView = deleteLeagueView;
        this.listTeamsView = listTeamsView;
        this.listPlayersView = listPlayersView;
        this.statisticsView = statisticsView;

        this.leagueManager = leagueManager;
        this.teamManager = teamManager;
        this.userManager = userManager;
        this.matchManager = matchManager;

        leagueView.registerController(this);
        createLeagueView.registerController(this);
    }

    /**
     * Method that receives an event and acts accordinly.
     * It is used only for buttons.
     * @param e the event to be processed
     */
    @Override
    public void actionPerformed(ActionEvent e) {

        // Listener for the Create button in the LeagueView
        if(e.getActionCommand().equals("CREATE_LEAGUE_BUTTON")){
            createLeagueView.reset();
            createLeagueView.resetComboBox();
            baseView.setChangeView(CreateLeagueView.IDENTIFIER);
            createLeagueView.registerController(this);

        // Listener for the Delete button in the LeagueView
        } else if(e.getActionCommand().equals("DELETE_LEAGUE_BUTTON")){
            deleteLeagueView.updateLeagueList(leagueManager.getLeagues(null));
            baseView.setChangeView(DeleteLeagueView.IDENTIFIER);
            deleteLeagueView.registerController(this);

        // Listener for the Add Teams button in the CreateLeagueView
        } else if(e.getActionCommand().equals("ADD_TEAMS")){

            if(leagueManager.validateLeague(createLeagueView.getName(), createLeagueView.getStartDate(), createLeagueView.getStartTime())){

                addTeamsToLeagueView.updateTeamList(teamManager.getAllTeams()); // Update the List of teams to choose

                baseView.setChangeView(AddTeamsToLeagueView.IDENTIFIER);
                addTeamsToLeagueView.registerController(this);
            } else{
                JOptionPane.showMessageDialog(createLeagueView, "League name is not unique or start date is in the past", "Error", JOptionPane.ERROR_MESSAGE);
            }

        // Listener for the button Final Create League in the AddTeamsToLeague view
        } else if(e.getActionCommand().equals("FINAL_CREATE_LEAGUE")){

            leagueManager.createLeague(createLeagueView.getName(), createLeagueView.getStartDate(), createLeagueView.getStartTime());

            leagueManager.createCalendar(createLeagueView.getName(), createLeagueView.getStartDate(), createLeagueView.getStartTime(),
                                        addTeamsToLeagueView.getCheckBoxes());
            User user = userManager.getUser();
            leagueView.updateLeagueList(leagueManager.getLeagues(user), leagueManager.getLeaguesStatus(user), leagueManager.getLeaguesNumberTeams(user));
            baseView.setChangeView(LeagueView.IDENTIFIER);
            leagueView.registerController(this);

        // Listener for the button Final Delete League in the DeleteLeague view
        } else if(e.getActionCommand().equals("FINAL_DELETE_LEAGUE")){
            ArrayList<String> leaguesToDelete = deleteLeagueView.getCheckBoxes();
            for (int i = 0; i < leaguesToDelete.size(); i++) {
                matchManager.forceCloseMatchesByLeague(leaguesToDelete.get(i));
            }
            leagueManager.deleteLeagues(leaguesToDelete);
            leagueView.updateLeagueList(leagueManager.getLeagues(null), leagueManager.getLeaguesStatus(null), leagueManager.getLeaguesNumberTeams(null)); // Update the list of teamsView
            baseView.setChangeView(LeagueView.IDENTIFIER);
            leagueView.registerController(this);

        } else if (e.getActionCommand().equals("COMBO_DAY")){
            int selectedDay = createLeagueView.getDay();
            createLeagueView.setDay(selectedDay);


        } else if(e.getActionCommand().equals("COMBO_MONTH")){
            int selectedMonth = createLeagueView.getMonth();
            createLeagueView.setMonth(selectedMonth);


        } else if(e.getActionCommand().equals("COMBO_YEAR")){

            int selectedYear = createLeagueView.getYear();
            createLeagueView.setYear(selectedYear);


        } else if(e.getActionCommand().equals("COMBO_HOURS")){
            int selectedHour = createLeagueView.getHour();
            createLeagueView.setHour(selectedHour);


        } else if (e.getActionCommand().equals("COMBO_MINUTES")){
            int selectedMinutes = createLeagueView.getMinutes();
            createLeagueView.setMinutes(selectedMinutes);


        } else if (e.getActionCommand().equals("SHOW_STATS_BUTTON")) {
            statisticsView.updateGraph(leagueManager.getStatisticsByLeague(leagueDisplayed));
            baseView.setChangeView(StatisticsView.IDENTIFIER);

        } else if (e.getActionCommand().equals("GO_BACK_BUTTON")) {

            baseView.setChangeView(ListTeamsView.IDENTIFIER);

        }

    }

    /**
     * Method that receives an event and acts accordinly, depending on the JTable clicked.
     * @param e the event to be processed
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        JTable table = (JTable) e.getSource();
        int row = table.rowAtPoint(e.getPoint());
        int column = table.columnAtPoint(e.getPoint());

        if(e.getSource() == leagueView.getTable()){

            if (row >= 0 && column >= 0) {
                this.leagueDisplayed = (String) table.getValueAt(row, 0);
                listTeamsView.updateTeamList(leagueManager.getTeamsByLeague(leagueDisplayed), leagueManager.getTeamsWonGames(leagueDisplayed),
                        leagueManager.getTeamsLostGames(leagueDisplayed), leagueManager.getTeamsTiedGames(leagueDisplayed), leagueManager.getTeamsNumberPlayers(leagueDisplayed));
                listTeamsView.registerController(this::actionPerformed, this);
                baseView.setChangeView(ListTeamsView.IDENTIFIER);
            }

        }else if (e.getSource() == listTeamsView.getTable()){

            if (row >= 0 && column >= 0) {
                Object team = table.getValueAt(row, 0);
                listPlayersView.updatePlayerList(teamManager.getPlayersByTeam((String) team));
                listPlayersView.registerController(this::actionPerformed);
                baseView.setChangeView(ListPlayersView.IDENTIFIER);
            }
        }

    }

    /**
     * Method not used.
     * @param e the event to be processed
     */
    @Override
    public void mousePressed(MouseEvent e) {

    }

    /**
     * Method not used.
     * @param e the event to be processed
     */

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    /**
     * Method not used.
     * @param e the event to be processed
     */
    @Override
    public void mouseEntered(MouseEvent e) {

    }

    /**
     * Method not used.
     * @param e the event to be processed
     */
    @Override
    public void mouseExited(MouseEvent e) {

    }

    /**
     * Updates the data, both in listTeamsView and in League View.
     */
    public void updateData() {

        listTeamsView.updateTeamList(leagueManager.getTeamsByLeague(leagueDisplayed), leagueManager.getTeamsWonGames(leagueDisplayed),
                leagueManager.getTeamsLostGames(leagueDisplayed), leagueManager.getTeamsTiedGames(leagueDisplayed),
                leagueManager.getTeamsNumberPlayers(leagueDisplayed));

        leagueView.updateLeagueList(leagueManager.getLeagues(null), leagueManager.getLeaguesStatus(null), leagueManager.getLeaguesNumberTeams(null));
    }

    /**
     * Calls the statisticsView to update the graph statistics.
     */

    public void updateStatistics(){
        statisticsView.updateGraph(leagueManager.getStatisticsByLeague(leagueDisplayed));
    }

}
