package persistence;

import business.entities.League;
import business.entities.Team;
import business.entities.User;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class TeamSQLDAO implements TeamDAO{

    private static ConnectionUtil ddbb;
    private static Connection connection;

    /**
     * Constructs a new TeamSQLDAO object.
     * Initializes the database connection using ConnectionUtil and the loaded configuration.
     */
    public TeamSQLDAO(){
        ddbb = new ConnectionUtil();
        this.connection = ddbb.connect(ConfigJSONDAO.load());
    }


    /**
     * Retrieves all teams from the data storage.
     *
     * @return An ArrayList containing all the teams.
     */
    @Override
    public ArrayList<Team> getAll() {
        ArrayList<Team> teams = new ArrayList<>();
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT team_name FROM team");
            while (resultSet.next()) {
                Team team = new Team(resultSet.getString("team_name"));
                teams.add(team);
            }
            statement.close();
        } catch (SQLException e) {
            //System.err.println("Error retrieving teams: " + e.getMessage());
        }
        return teams;
    }


    /**
     * Saves a team to the data storage.
     *
     * @param team The Team object to be saved.
     * @return True if the team was successfully saved, false otherwise.
     */
    @Override
    public boolean save(Team team) {
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate(
                    "INSERT INTO team (team_name) VALUES ('"+team.getName()+"');");
            statement.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            //System.err.println("Error saving team: " + e.getMessage());
            return false;
        }
    }

    private boolean delete(String teamName) {
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate(
                    "DELETE FROM team WHERE team_name = '"+teamName+"';");
            statement.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            //System.err.println("Error deleting team: " + e.getMessage());
            return false;
        }
    }

    private boolean deleteTeamForMatches(String teamName){
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(
                    "DELETE FROM matches WHERE team_1 = '"+teamName+"';");
            statement.close();

            Statement statement2 = connection.createStatement();
            statement2.executeUpdate(
                    "DELETE FROM matches WHERE team_2 = '"+teamName+"';");
            statement2.close();

            return true;
        } catch (SQLException e) {
            //System.out.println("Error deleting team: " + e.getMessage());
            return false;
        }
    }

    private boolean deleteTeamForScores(String teamName){
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(
                    "DELETE FROM scores WHERE team_name = '"+teamName+"';");
            statement.close();

            return true;
        } catch (SQLException e) {
            //System.out.println("Error deleting team: " + e.getMessage());
            return false;
        }
    }


    /**
     * Deletes multiple teams from the data storage along with their related records.
     *
     * @param teams The list of team names to be deleted.
     * @return True if all teams were successfully deleted, false otherwise.
     */
    @Override
    public boolean deleteTeams(ArrayList<String> teams) {
        try {
            connection.setAutoCommit(false);  // Start a transaction

            for (String team : teams) {
                if (!deleteTeamForScores(team) || !deleteTeamForMatches(team) || !deleteTeamFromLeague(team)
                        || !deleteTeamForPlayers(team) || !delete(team)) {
                    connection.rollback();  // Roll back the transaction if any deletion fails
                    return false;
                }
            }

            connection.commit();  // Commit the transaction if all deletions are successful
            return true;
        } catch (SQLException e) {
            try {
                connection.rollback();  // Roll back the transaction on exception
            } catch (SQLException rollbackException) {
                //System.err.println("Error rolling back transaction: " + rollbackException.getMessage());
            }
            //System.err.println("Error deleting teams: " + e.getMessage());
            return false;
        } finally {
            try {
                connection.setAutoCommit(true);  // Set auto-commit back to true
            } catch (SQLException e) {
                //System.err.println("Error resetting auto-commit: " + e.getMessage());
            }
        }
    }

    /**
     * Retrieves all players of a team from the data storage.
     *
     * @param teamName The name of the team.
     * @return An ArrayList containing all the players of the team.
     */
    @Override
    public ArrayList<User> getPlayersByTeam(String teamName) {
        ArrayList<User> players = new ArrayList<>();
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT player.dni, email, player_name, squad_number, phone FROM player " +
                    "JOIN has_team ON player.dni = has_team.dni WHERE has_team.team_name = '"+teamName+"';");
            while (resultSet.next()) {
                User user = new User(resultSet.getString("dni"),
                        resultSet.getString("email"),
                        " ",
                        resultSet.getString("player_name"),
                        resultSet.getInt("squad_number"),
                        resultSet.getString("phone"));
                players.add(user);
            }
            statement.close();
        } catch (SQLException e) {
            //System.out.println("Error retrieving teams: " + e.getMessage());
        }
        return players;
    }

    /**
     * Retrieves all teams associated with a user from the data storage.
     *
     * @param user The user's DNI.
     * @return An ArrayList containing all the teams associated with the user.
     */
    @Override
    public ArrayList<Team> getTeamsByUser(String user) {
        ArrayList<Team> teams = new ArrayList<>();
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT team_name FROM has_team WHERE dni = '" + user + "';");

            while (resultSet.next()) {
                //System.out.println(resultSet.getFetchSize());
                String teamName = resultSet.getString("team_name");
                Team team = new Team(teamName);
                teams.add(team);
            }
            statement.close();
        } catch (SQLException e) {
            //System.out.println("Error retrieving teams: " + e.getMessage());
        }
        return teams;
    }


    private boolean deleteTeamFromLeague(String teamName){
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(
                    "DELETE FROM has_league WHERE team_name = '"+teamName+"';");
            statement.close();
            return true;
        } catch (SQLException e) {
            //System.out.println("Error deleting team: " + e.getMessage());
            return false;
        }
    }

    private boolean deleteTeamForPlayers(String teamName){
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(
                    "DELETE FROM has_team WHERE team_name = '"+teamName+"';");
            statement.close();
            return true;
        } catch (SQLException e) {
            //System.out.println("Error deleting team: " + e.getMessage());
            return false;
        }
    }

    /**
     * Checks if the given team name is unique in the data storage.
     *
     * @param name The name to be checked.
     * @return True if the name is unique, false otherwise.
     */
    @Override
    public boolean nameUnique(String name) {
        boolean unique = true;
        ArrayList<Team> teams = getAll();
        for (Team team: teams) {
            unique &= !name.equals(team.getName());
        }
        return unique;
    }

    /**
     * Saves a member to a team in the data storage.
     *
     * @param dni      The DNI of the user.
     * @param teamName The name of the team.
     * @return True if the operation was successful, false otherwise.
     */
    @Override
    public boolean saveMember(String dni, String teamName) {
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate(
                    "INSERT INTO has_team (dni, team_name) VALUES ('"+dni+"', '"+teamName+"');");
            statement.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            //System.err.println("Error adding user to team: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves the number of games won by a team in a league from the data storage.
     *
     * @param team   The name of the team.
     * @param league The name of the league.
     * @return The number of games won by the team in the league.
     */
    @Override
    public int getWonGames(String team, String league) {
        int wonGames = -1;
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT has_league.matches_won FROM has_league " +
                    "WHERE has_league.league_name = '"+ league +"' AND has_league.team_name = '"+ team +"';");
            while (resultSet.next()) {
                wonGames = resultSet.getInt("matches_won");
            }
            statement.close();
        } catch (SQLException e) {
            //System.err.println("Error retrieving leagues: " + e.getMessage());
        }
        return wonGames;
    }

    /**
     * Retrieves the number of games tied by a team in a league from the data storage.
     *
     * @param team   The name of the team.
     * @param league The name of the league.
     * @return The number of games tied by the team in the league.
     */
    @Override
    public int getTiedGames(String team, String league) {
        int tiedGames = -1;
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT has_league.matches_tied FROM has_league " +
                    "WHERE has_league.league_name = '"+ league +"' AND has_league.team_name = '"+ team +"';");
            while (resultSet.next()) {
                tiedGames = resultSet.getInt("matches_tied");
            }
            statement.close();
        } catch (SQLException e) {
            //System.err.println("Error retrieving leagues: " + e.getMessage());
        }
        return tiedGames;
    }

    /**
     * Retrieves the number of games lost by a team in a league from the data storage.
     *
     * @param team   The name of the team.
     * @param league The name of the league.
     * @return The number of games lost by the team in the league.
     */
    @Override
    public int getLostGames(String team, String league) {
        int lostGames = -1;
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT has_league.matches_lost FROM has_league " +
                    "WHERE has_league.league_name = '"+ league +"' AND has_league.team_name = '"+ team +"';");
            while (resultSet.next()) {
                lostGames = resultSet.getInt("matches_lost");
            }
            statement.close();
        } catch (SQLException e) {
            //System.err.println("Error retrieving leagues: " + e.getMessage());
        }
        return lostGames;
    }

    /**
     * Retrieves the number of players in a team from the data storage.
     *
     * @param team The name of the team.
     * @return The number of players in the team.
     */
    @Override
    public int getNumberPlayers(String team) {
        int num = 0;
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT COUNT(*) AS num FROM has_team " +
                    "WHERE has_team.team_name = '"+ team +"' GROUP BY has_team.team_name;");
            while (resultSet.next()) {
                num = resultSet.getInt("num");
            }
            statement.close();
        } catch (SQLException e) {
            //System.err.println("Error retrieving leagues: " + e.getMessage());
        }
        return num;
    }

}
