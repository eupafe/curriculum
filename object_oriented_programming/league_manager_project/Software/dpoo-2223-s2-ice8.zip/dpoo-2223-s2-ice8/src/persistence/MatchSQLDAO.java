package persistence;

import business.entities.Match;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class MatchSQLDAO implements MatchDAO{

    private static ConnectionUtil ddbb;

    private static Connection connection;

    /**
     * Constructs a MatchSQLDAO object and establishes a connection to the database.
     */
    public MatchSQLDAO(){
        ddbb = new ConnectionUtil();
        this.connection = ddbb.connect(ConfigJSONDAO.load());
    }


    /**
     * Retrieves all matches from the database.
     *
     * @return an ArrayList of all matches.
     */
    @Override
    public ArrayList<Match> getAll() {
        ArrayList<Match> matches = new ArrayList<>();
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT team_1, team_2, league_name,  match_day, match_date, match_time, duration, match_result FROM matches");
            while (resultSet.next()) {
                Match match = new Match(
                        resultSet.getString("team_1"),
                        resultSet.getString("team_2"),
                        resultSet.getString("league_name"),
                        resultSet.getInt("match_day"),
                        resultSet.getDate("match_date").toLocalDate(),
                        resultSet.getTime("match_time").toLocalTime(),
                        resultSet.getInt("duration"),
                        resultSet.getInt("match_result"));

                matches.add(match);
            }
            statement.close();
        } catch (SQLException e) {
        }
        return matches;
    }

    /**
     * Retrieves matches associated with a user.
     *
     * @param user the user associated with the matches.
     * @return an ArrayList of matches associated with the user.
     */
    @Override
    public ArrayList<Match> getMatchesByUser(String user) {
        ArrayList<Match> matches = new ArrayList<>();

        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM matches " +
                    "JOIN has_league ON has_league.league_name = matches.league_name " +
                    "JOIN has_team ON has_league.team_name = has_team.team_name " +
                    "WHERE has_team.dni = '" + user + "';");
            while (resultSet.next()) {
                Match match = new Match(
                        resultSet.getString("team_1"),
                        resultSet.getString("team_2"),
                        resultSet.getString("league_name"),
                        resultSet.getInt("match_day"),
                        resultSet.getDate("match_date").toLocalDate(),
                        resultSet.getTime("match_time").toLocalTime(),
                        resultSet.getInt("duration"),
                        resultSet.getInt("match_result"));

                matches.add(match);
            }
            statement.close();
        } catch (SQLException e) {
        }

        return matches;
    }

    /**
     * Saves a match in the database.
     *
     * @param match the match to be saved.
     * @return true if the match is successfully saved, false otherwise.
     */
    @Override
    public boolean save(Match match) {
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate("INSERT INTO matches (team_1, team_2, league_name, match_day, match_date, match_time, duration, match_result) VALUES ('" + match.getTeam1() + "', '" + match.getTeam2() + "', '" + match.getLeagueName() + "', '" + match.getMatchDay() + "', '" + match.getDate() + "', '" + match.getTime() + "', '" + match.getDuration() + "', " + match.getResult() + ")");
            statement.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Updates a match in the database.
     *
     * @param match the match to be updated.
     * @return true if the match is successfully updated, false otherwise.
     */
    @Override
    public boolean update(Match match) {
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate(
                    "UPDATE matches SET match_date = '"+ match.getDate() +"', " +
                            "match_time = '" + match.getTime() +"', " +
                            "duration = " + match.getDuration() + ", " +
                            "match_result = " + match.getResult() +
                            " WHERE team_1 = '"+match.getTeam1() + "' AND" +
                            " team_2 = '" + match.getTeam2() + "' AND" +
                            " league_name = '" + match.getLeagueName()+ "' AND" +
                            " match_day = " + match.getMatchDay() + ";"
            );
            statement.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Deletes a match from the database.
     *
     * @param match the match to be deleted.
     * @return true if the match is successfully deleted, false otherwise.
     */
    @Override
    public boolean delete(Match match) {
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate(
                    "DELETE FROM matches WHERE" +
                            " team_1 = '"+match.getTeam1() + "' AND" +
                            " team_2 = '" + match.getTeam2() + "' AND" +
                            " league_name = '" + match.getLeagueName()+ "' AND" +
                            " match_day = " + match.getMatchDay() + ";");
            statement.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Retrieves matches associated with a league.
     *
     * @param league the league associated with the matches.
     * @return an ArrayList of matches associated with the league.
     */
    @Override
    public ArrayList<Match> getMatchesByLeague(String league) {
        ArrayList<Match> matches = new ArrayList<>();

        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM matches " +
                    "WHERE matches.league_name = '" + league + "';");
            while (resultSet.next()) {
                Match match = new Match(
                        resultSet.getString("team_1"),
                        resultSet.getString("team_2"),
                        resultSet.getString("league_name"),
                        resultSet.getInt("match_day"),
                        resultSet.getDate("match_date").toLocalDate(),
                        resultSet.getTime("match_time").toLocalTime(),
                        resultSet.getInt("duration"),
                        resultSet.getInt("match_result"));

                matches.add(match);
            }
            statement.close();
        } catch (SQLException e) {
        }

        return matches;
    }

    /**
     * Retrieves matches associated with a team.
     *
     * @param team the team associated with the matches.
     * @return an ArrayList of matches associated with the team.
     */
    @Override
    public ArrayList<Match> getMatchesByTeam(String team) {
        ArrayList<Match> matches = new ArrayList<>();

        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM matches " +
                    "WHERE matches.team_1 = '" + team + "' OR matches.team_2 = '"+ team +"';");
            while (resultSet.next()) {
                Match match = new Match(
                        resultSet.getString("team_1"),
                        resultSet.getString("team_2"),
                        resultSet.getString("league_name"),
                        resultSet.getInt("match_day"),
                        resultSet.getDate("match_date").toLocalDate(),
                        resultSet.getTime("match_time").toLocalTime(),
                        resultSet.getInt("duration"),
                        resultSet.getInt("match_result"));

                matches.add(match);
            }
            statement.close();
        } catch (SQLException e) {
        }

        return matches;
    }

    /**
     * Retrieves the points of a team in a league.
     *
     * @param league the league associated with the points.
     * @param team   the team associated with the points.
     * @return an ArrayList of points for the team in the league.
     */
    @Override
    public ArrayList<Integer> getPoints(String league, String team) {
        ArrayList<Integer> points = new ArrayList<>();

        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT scores.score FROM scores " +
                    "WHERE scores.league_name = '" + league + "' AND " +
                    "scores.team_name = '"+ team +"' " +
                    "ORDER BY scores.match_day ASC;");
            while (resultSet.next()) {
                points.add(resultSet.getInt("score"));
            }
            statement.close();
        } catch (SQLException e) {
        }

        return points;
    }
}
