package persistence;

public class DatabaseConfig {
    private String host;
    private int port;
    private String name;
    private String username;
    private String password;

    public DatabaseConfig(String host, int port, String name, String username, String password) {
        this.host = host;
        this.port = port;
        this.name = name;
        this.username = username;
        this.password = password;
    }

    /**
     * Returns the port number of the database.
     *
     * @return the port number
     */
    public int getPort() {
        return port;
    }

    /**
     * Returns the host name of the database.
     *
     * @return the host name
     */
    public String getHost() {
        return host;
    }

    /**
     * Returns the name of the database.
     *
     * @return the database name
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the username used to connect to the database.
     *
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Returns the password used to connect to the database.
     *
     * @return the password
     */
    public String getPassword() {
        return password;
    }
}
