package persistence;

import business.entities.User;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * The PlayerSQLDAO class implements the PlayerDAO interface to provide access to User objects stored in a SQL database.
 */
public class PlayerSQLDAO implements PlayerDAO {

    private static ConnectionUtil ddbb;
    private static Connection connection;

    /**
     * Constructs a new PlayerSQLDAO object and establishes a database connection.
     */
    public PlayerSQLDAO() {
        this.ddbb = new ConnectionUtil();
        this.connection = ddbb.connect(ConfigJSONDAO.load());
    }

    /**
     * Retrieves a user from the data storage based on their DNI.
     *
     * @param dni The DNI of the user to retrieve.
     * @return A User object representing the user with the specified DNI, or null if not found.
     */
    @Override
    public User getByDNI(String dni) {
        User user = null;
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT dni, email, player_password, player_name, squad_number, phone FROM player WHERE dni = '" + dni + "';");
            while (resultSet.next()) {
                user = new User(resultSet.getString("dni"),
                        resultSet.getString("email"),
                        resultSet.getString("player_password"),
                        resultSet.getString("player_name"),
                        resultSet.getInt("squad_number"),
                        resultSet.getString("phone"));
            }
        } catch (SQLException e) {
        }
        return user;
    }

    /**
     * Retrieves a user from the data storage based on their email.
     *
     * @param email The email address of the user to retrieve.
     * @return A User object representing the user with the specified email, or null if not found.
     */
    @Override
    public User getByEmail(String email) {
        User user = null;
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT dni, email, player_password, player_name, squad_number, phone FROM player WHERE email = '" + email + "';");
            while (resultSet.next()) {
                user = new User(resultSet.getString("dni"),
                        resultSet.getString("email"),
                        resultSet.getString("player_password"),
                        resultSet.getString("player_name"),
                        resultSet.getInt("squad_number"),
                        resultSet.getString("phone"));
            }
        } catch (SQLException e) {
        }
        return user;
    }

    /**
     * Saves a user to the data storage.
     *
     * @param user The User object to be saved.
     * @return True if the user was successfully saved, false otherwise.
     */
    @Override
    public boolean save(User user) {
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate("INSERT INTO player (dni, email, player_password, player_name, squad_number, phone)" +
                    " VALUES ('" + user.getDNI() + "', '" + user.getEmail() + "', '" + user.getPassword() + "', '" + user.getName() + "', " + user.getSquadNumber() + ", '" + user.getPhone() + "')");
            statement.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Updates a user in the data storage.
     *
     * @param user The User object to be updated.
     * @return True if the user was successfully updated, false otherwise.
     */
    @Override
    public boolean update(User user) {
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate(
                    "UPDATE player SET player_password = '" + user.getPassword() + "', " +
                            "player_name = '" + user.getName() + "', " +
                            "squad_number = " + user.getSquadNumber() + ", " +
                            "phone = '" + user.getPhone() + "' " +
                            "WHERE DNI = '" + user.getDNI() + "';"
            );
            statement.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Deletes a user from the team in the data storage.
     *
     * @param dni The DNI of the user to be deleted from the team.
     * @return True if the user was successfully deleted from the team, false otherwise.
     */
    private boolean deleteUserFromTeam(String dni) {
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(
                    "DELETE FROM has_team WHERE dni = '" + dni + "';"
            );
            statement.close();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Deletes a user from the data storage.
     *
     * @param dni The DNI of the user to be deleted.
     * @return True if the user was successfully deleted, false otherwise.
     */
    private boolean deleteUser(String dni) {
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate(
                    "DELETE FROM player WHERE dni = '" + dni + "';"
            );
            statement.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Deletes a user from the data storage, including removing them from any associated teams.
     *
     * @param user The User object to be deleted.
     * @return True if the user was successfully deleted, false otherwise.
     */
    public boolean delete(User user) {
        try {
            connection.setAutoCommit(false);  // Start a transaction
            if (user != null) {
                if (!deleteUserFromTeam(user.getDNI()) || !deleteUser(user.getDNI())) {
                    connection.rollback();  // Roll back the transaction if any deletion fails
                    return false;
                }
            }
            connection.commit();  // Commit the transaction if all deletions are successful
            return true;
        } catch (SQLException e) {
            try {
                connection.rollback();  // Roll back the transaction on exception
            } catch (SQLException rollbackException) {
                //System.err.println("Error rolling back transaction: " + rollbackException.getMessage());
            }
            //System.err.println("Error deleting player: " + e.getMessage());
            return false;
        } finally {
            try {
                connection.setAutoCommit(true);  // Set auto-commit back to true
            } catch (SQLException e) {
                //System.err.println("Error resetting auto-commit: " + e.getMessage());
            }
        }
    }

    /**
     * Validates the login credentials of a user.
     *
     * @param login    The DNI or email of the user.
     * @param password The password of the user.
     * @return True if the login credentials are valid, false otherwise.
     */
    @Override
    public boolean validate(String login, String password) {
        return (getByDNI(login) != null && getByDNI(login).getPassword().equals(password))
                || (getByEmail(login) != null && getByEmail(login).getPassword().equals(password));
    }

    /**
     * Checks if a player with the given DNI or email already exists in the data storage.
     *
     * @param dni   The DNI to check.
     * @param email The email to check.
     * @return True if a player with the given DNI or email already exists, false otherwise.
     */
    @Override
    public boolean playerExists(String dni, String email) {
        return (getByDNI(dni) != null) || (getByEmail(email) != null);
    }
}
