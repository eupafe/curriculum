package persistence;

import business.entities.Match;

import java.util.ArrayList;

/**
 * The MatchDAO interface provides methods to access and manipulate Match objects in the data storage.
 */
public interface MatchDAO {

    /**
     * Retrieves all matches stored in the data storage.
     *
     * @return An ArrayList of Match objects representing all the matches.
     */
    ArrayList<Match> getAll();

    /**
     * Retrieves matches associated with a specific user.
     *
     * @param user The username or identifier of the user.
     * @return An ArrayList of Match objects representing the matches associated with the user.
     */
    ArrayList<Match> getMatchesByUser(String user);

    /**
     * Saves a match in the data storage.
     *
     * @param match The Match object to be saved.
     * @return True if the match was successfully saved, false otherwise.
     */
    boolean save(Match match);

    /**
     * Updates an existing match in the data storage.
     *
     * @param match The Match object containing the updated information.
     * @return True if the match was successfully updated, false otherwise.
     */
    boolean update(Match match);

    /**
     * Deletes a match from the data storage.
     *
     * @param match The Match object to be deleted.
     * @return True if the match was successfully deleted, false otherwise.
     */
    boolean delete(Match match);

    /**
     * Retrieves matches associated with a specific league.
     *
     * @param league The name of the league.
     * @return An ArrayList of Match objects representing the matches associated with the league.
     */
    ArrayList<Match> getMatchesByLeague(String league);

    /**
     * Retrieves matches associated with a specific team.
     *
     * @param team The name of the team.
     * @return An ArrayList of Match objects representing the matches associated with the team.
     */
    ArrayList<Match> getMatchesByTeam(String team);

    /**
     * Retrieves the points earned by a team in a specific league.
     *
     * @param league The name of the league.
     * @param team   The name of the team.
     * @return An ArrayList of integers representing the points earned by the team in the league.
     */
    ArrayList<Integer> getPoints(String league, String team);
}
