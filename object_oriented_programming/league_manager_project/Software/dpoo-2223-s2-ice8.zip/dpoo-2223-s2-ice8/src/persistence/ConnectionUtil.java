package persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ConnectionUtil {

    /**
     * Establishes a connection to the PostgreSQL database using the provided database configuration.
     *
     * @param config the database configuration settings
     * @return the established database connection
     */
    public Connection connect(DatabaseConfig config) {
        Connection connection = null;
        try {
            // Load the PostgreSQL driver
            Class.forName("org.postgresql.Driver");

            // Create the connection using the database configuration settings
            connection = DriverManager.getConnection("jdbc:postgresql://" + config.getHost() + ":" + config.getPort() + "/" + config.getName() + "?user=" + config.getUsername() + "&password=" + config.getPassword());

            if (connection != null) {

                // Create a statement and execute a test query
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery("SELECT version()");
                while (resultSet.next()) {
                }
            } else {
            }
        } catch (Exception e) {
        }

        return connection;
    }
}
