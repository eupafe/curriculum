package persistence;

import business.entities.User;

import java.util.ArrayList;

public interface PlayerDAO {

    /**
     * Retrieves a user from the data storage based on their DNI (Documento Nacional de Identidad).
     *
     * @param dni The DNI of the user.
     * @return The User object if found, null otherwise.
     */
    User getByDNI(String dni);

    /**
     * Retrieves a user from the data storage based on their email.
     *
     * @param email The email of the user.
     * @return The User object if found, null otherwise.
     */
    User getByEmail(String email);

    /**
     * Saves a user to the data storage.
     *
     * @param user The User object to be saved.
     * @return True if the user was successfully saved, false otherwise.
     */
    boolean save(User user);

    /**
     * Updates a user in the data storage.
     *
     * @param user The User object to be updated.
     * @return True if the user was successfully updated, false otherwise.
     */
    boolean update(User user);

    /**
     * Deletes a user from the data storage.
     *
     * @param user The User object to be deleted.
     * @return True if the user was successfully deleted, false otherwise.
     */
    boolean delete(User user);

    /**
     * Validates the login credentials of a user.
     *
     * @param login    The DNI or email of the user.
     * @param password The password of the user.
     * @return True if the login credentials are valid, false otherwise.
     */
    boolean validate(String login, String password);

    /**
     * Checks if a player with the given DNI or email already exists in the data storage.
     *
     * @param dni   The DNI to check.
     * @param email The email to check.
     * @return True if a player with the given DNI or email already exists, false otherwise.
     */
    boolean playerExists(String dni, String email);
}
