package persistence;

import business.entities.League;
import business.entities.Team;
import business.entities.User;

import java.util.ArrayList;

/**
 * The TeamDAO interface provides methods for accessing and manipulating team data in the data storage.
 */
public interface TeamDAO {

    /**
     * Retrieves all teams from the data storage.
     *
     * @return An ArrayList containing all the teams.
     */
    ArrayList<Team> getAll();

    /**
     * Saves a team in the data storage.
     *
     * @param team The team to be saved.
     * @return True if the team is successfully saved, false otherwise.
     */
    boolean save(Team team);

    /**
     * Checks if a team name is unique in the data storage.
     *
     * @param name The name to be checked for uniqueness.
     * @return True if the team name is unique, false otherwise.
     */
    boolean nameUnique(String name);

    /**
     * Deletes multiple teams from the data storage.
     *
     * @param teams An ArrayList of team names to be deleted.
     * @return True if all teams are successfully deleted, false otherwise.
     */
    boolean deleteTeams(ArrayList<String> teams);

    /**
     * Retrieves teams associated with a user from the data storage.
     *
     * @param user The user for which to retrieve teams.
     * @return An ArrayList containing the teams associated with the user.
     */
    ArrayList<Team> getTeamsByUser(String user);

    /**
     * Retrieves players of a team from the data storage.
     *
     * @param teamName The name of the team.
     * @return An ArrayList containing the players of the team.
     */
    ArrayList<User> getPlayersByTeam(String teamName);

    /**
     * Saves a member to a team in the data storage.
     *
     * @param dni      The DNI of the member to be saved.
     * @param teamName The name of the team.
     * @return True if the member is successfully saved to the team, false otherwise.
     */
    boolean saveMember(String dni, String teamName);

    /**
     * Retrieves the number of won games for a team in a specific league from the data storage.
     *
     * @param team   The name of the team.
     * @param league The name of the league.
     * @return The number of won games for the team in the league.
     */
    int getWonGames(String team, String league);

    /**
     * Retrieves the number of tied games for a team in a specific league from the data storage.
     *
     * @param team   The name of the team.
     * @param league The name of the league.
     * @return The number of tied games for the team in the league.
     */
    int getTiedGames(String team, String league);

    /**
     * Retrieves the number of lost games for a team in a specific league from the data storage.
     *
     * @param team   The name of the team.
     * @param league The name of the league.
     * @return The number of lost games for the team in the league.
     */
    int getLostGames(String team, String league);

    /**
     * Retrieves the number of players in a team from the data storage.
     *
     * @param team The name of the team.
     * @return The number of players in the team.
     */
    int getNumberPlayers(String team);
}

