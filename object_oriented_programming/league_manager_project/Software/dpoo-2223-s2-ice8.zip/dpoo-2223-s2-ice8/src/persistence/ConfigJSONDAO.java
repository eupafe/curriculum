package persistence;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ConfigJSONDAO {

    private static final Gson gson = new Gson();

    /**
     * Load the config.json file and retrieve the database configuration settings.
     *
     * @return the database configuration settings
     */
    public static DatabaseConfig load() {
        try {
            FileReader fileReader = new FileReader("src/config.json");
            JsonObject jsonObject = gson.fromJson(fileReader, JsonObject.class);
            JsonObject dbJson = jsonObject.getAsJsonObject("database");

            String host = dbJson.get("host").getAsString();
            int port = dbJson.get("port").getAsInt();
            String name = dbJson.get("name").getAsString();
            String username = dbJson.get("username").getAsString();
            String password = dbJson.get("password").getAsString();

            return new DatabaseConfig(host, port, name, username, password);
        } catch (FileNotFoundException e) {
            return null;
        }
    }

    /**
     * Get the admin password from the config.json file.
     *
     * @return the admin password
     */
    public String getAdminPassword() {
        String adminPassword;
        try {
            JsonObject config = gson.fromJson(new FileReader("src/config.json"), JsonObject.class);

            // Get the admin password
            adminPassword = config.get("admin_password").getAsString();

        } catch (FileNotFoundException e) {
            return null;
        }
        return adminPassword;
    }

    /**
     * Get the match duration in minutes from the config.json file.
     *
     * @return the match duration in minutes
     */
    public int getMatchDuration() {
        int duration;
        try {
            JsonObject config = gson.fromJson(new FileReader("src/config.json"), JsonObject.class);

            // Get the match duration
            duration = config.get("match_duration_minutes").getAsInt();

        } catch (FileNotFoundException e) {
            return -1;
        }
        return duration;
    }
}
