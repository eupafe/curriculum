package persistence;

import business.entities.League;
import business.entities.Match;
import business.entities.Team;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * The LeagueSQLDAO class is responsible for performing CRUD operations
 * for League objects in a SQL database.
 */
public class LeagueSQLDAO implements LeagueDAO{
    private static ConnectionUtil ddbb;
    private static Connection connection;

    /**
     * Constructs a LeagueSQLDAO object and establishes a connection to the database.
     */
    public LeagueSQLDAO(){
        ddbb = new ConnectionUtil();
        this.connection = ddbb.connect(ConfigJSONDAO.load());
    }

    /**
     * Retrieves all leagues from the database.
     *
     * @return an ArrayList containing all the leagues in the database.
     */
    @Override
    public ArrayList<League> getAll() {
        ArrayList<League> leagues = new ArrayList<>();
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT league_name, start_day, start_time FROM league");
            while (resultSet.next()) {
                League league = new League(resultSet.getString("league_name"),
                        resultSet.getDate("start_day").toLocalDate(),
                        resultSet.getTime("start_time").toLocalTime());
                leagues.add(league);
            }
            statement.close();
        } catch (SQLException e) {
        }
        return leagues;
    }


    /**
     * Saves a league in the database.
     *
     * @param league the league to be saved.
     * @return true if the league was successfully saved, false otherwise.
     */
    @Override
    public boolean save(League league) {
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate("INSERT INTO league (league_name, start_day, start_time) VALUES ('" + league.getName() + "', '" + league.getStartDay() + "', '" + league.getStartTime() + "')");
            statement.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Deletes a league from the database.
     *
     * @param league the name of the league to be deleted.
     * @return true if the league was successfully deleted, false otherwise.
     */
    private boolean delete(String league) {
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate(
                    "DELETE FROM league WHERE league_name = '"+league+"';");
            statement.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Deletes league associations for teams from the database.
     *
     * @param league the name of the league for which team associations should be deleted.
     * @return true if the team associations were successfully deleted, false otherwise.
     */
    private boolean deleteLeagueForTeams(String league) {
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(
                    "DELETE FROM has_league WHERE league_name = '"+league+"';");
            statement.close();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Checks if a league name is unique in the database.
     *
     * @param name the name to be checked for uniqueness.
     * @return true if the name is unique, false otherwise.
     */
    @Override
    public boolean nameUnique(String name) {

        boolean unique = true;
        ArrayList<League> leagues = getAll();

        for (League league: leagues) {
            unique &= !name.equals(league.getName());
        }
        return unique;
    }

    /**
     * Retrieves leagues associated with a list of team names from the database.
     *
     * @param teamNames the list of team names to retrieve leagues for.
     * @return an ArrayList containing the leagues associated with the provided team names.
     */
    @Override
    public ArrayList<League> getLeaguesByTeam(ArrayList<String> teamNames) {
        ArrayList<League> leagues = new ArrayList<>();
        ArrayList<String> leagueNames = new ArrayList<>(); // Store unique league names

        try {
            Statement statement = connection.createStatement();

            for (String teamName : teamNames) {
                ResultSet resultSet = statement.executeQuery("SELECT l.league_name, l.start_day, l.start_time FROM league l JOIN has_league hl ON " +
                        "l.league_name = hl.league_name WHERE hl.team_name = '" + teamName + "';");

                while (resultSet.next()) {
                    String leagueName = resultSet.getString("league_name");

                    // Check if league name is already in the list, if not add it to leagues and list
                    if (!leagueNames.contains(leagueName)) {
                        League league = new League(leagueName,
                                resultSet.getDate("start_day").toLocalDate(),
                                resultSet.getTime("start_time").toLocalTime());
                        leagues.add(league);
                        leagueNames.add(leagueName);
                    }
                }

                resultSet.close();
            }

            statement.close();
        } catch (SQLException e) {
        }

        return leagues;
    }

    private boolean deleteLeagueForMatches(String league) {
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(
                    "DELETE FROM matches WHERE league_name = '"+league+"';");
            statement.close();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    private boolean deleteLeagueForScores(String league) {
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(
                    "DELETE FROM scores WHERE league_name = '"+league+"';");
            statement.close();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Deletes leagues and associated data from the database.
     *
     * @param leagues the list of league names to be deleted.
     * @return true if all leagues were successfully deleted, false otherwise.
     */
    @Override
    public boolean deleteLeagues(ArrayList<String> leagues) {
        try {
            connection.setAutoCommit(false);  // Start a transaction

            for (String league : leagues) {
                if (!deleteLeagueForScores(league) || !deleteLeagueForMatches(league)
                        || !deleteLeagueForTeams(league) || !delete(league)) {
                    connection.rollback();  // Roll back the transaction if any deletion fails
                    return false;
                }
            }
            connection.commit();  // Commit the transaction if all deletions are successful
            return true;
        } catch (SQLException e) {
            try {
                connection.rollback();  // Roll back the transaction on exception
            } catch (SQLException rollbackException) {
            }
            return false;
        } finally {
            try {
                connection.setAutoCommit(true);  // Set auto-commit back to true
            } catch (SQLException e) {
            }
        }
    }

    /**
     * Retrieves teams associated with a league from the database.
     *
     * @param leagueName the name of the league to retrieve teams for.
     * @return an ArrayList containing the teams associated with the specified league.
     */
    @Override
    public ArrayList<Team> getTeamsByLeague(String leagueName) {
        ArrayList<Team> teams = new ArrayList<>();
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT team_name FROM has_league WHERE league_name = '" + leagueName + "';");

            while (resultSet.next()) {
                //System.out.println(resultSet.getFetchSize());
                String teamName = resultSet.getString("team_name");
                Team team = new Team(teamName);
                teams.add(team);
            }
            statement.close();
        } catch (SQLException e) {
        }
        return teams;
    }

    /**
     * Adds a team to a league in the database.
     *
     * @param league the league to add the team to.
     * @param team   the name of the team to add.
     * @return true if the team was successfully added to the league, false otherwise.
     */
    @Override
    public boolean addTeam(League league, String team) {
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate("INSERT INTO has_league VALUES ('"+ team +"', '"+league.getName()+"', 0, 0, 0)");
            statement.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Updates the scores for a team in a league in the database.
     *
     * @param teamName   the name of the team.
     * @param leagueName the name of the league.
     * @param won        the number of matches won to update.
     * @param lost       the number of matches lost to update.
     * @param tied       the number of matches tied to update.
     * @return true if the scores were successfully updated, false otherwise.
     */
    @Override
    public boolean updateScore(String teamName, String leagueName, int won, int lost, int tied) {
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate("UPDATE has_league SET " +
                    "matches_won = matches_won + " + won + ", " +
                    "matches_lost = matches_lost + " + lost + ", " +
                    "matches_tied = matches_tied + " + tied + " " +
                    "WHERE team_name = '" + teamName + "' AND " +
                    "league_name = '" + leagueName + "';");
            statement.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Updates the match day for a match in the database.
     *
     * @param match the match to update the match day for.
     * @return true if the match day was successfully updated, false otherwise.
     */
    @Override
    public boolean updateMatchDay(Match match) {
        try {
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate("INSERT INTO scores VALUES ('"+ match.getTeam1()+ "', '"+ match.getLeagueName()+"', " +
                    match.getMatchDay()+ ", (SELECT has_league.matches_won FROM has_league WHERE has_league.league_name = '"+ match.getLeagueName()+"' AND " +
                    "team_name = '"+ match.getTeam1()+"'));" +
                    "INSERT INTO scores VALUES ('"+ match.getTeam2()+ "', '"+ match.getLeagueName()+"', " +
                    match.getMatchDay()+ ", (SELECT has_league.matches_won FROM has_league WHERE has_league.league_name = '"+ match.getLeagueName()+"' AND " +
                    "team_name = '"+ match.getTeam2()+"'));");
            statement.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            return false;
        }
    }


    /**
     * Retrieves the number of teams in a league.
     *
     * @param league the name of the league.
     * @return the number of teams in the league.
     */
    @Override
    public int getNumberTeams(String league) {
        int num = 0;
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT COUNT(*) AS num FROM has_league " +
                    "WHERE has_league.league_name = '"+ league +"' GROUP BY has_league.league_name;");
            while (resultSet.next()) {
                num = resultSet.getInt("num");
            }
            statement.close();
        } catch (SQLException e) {
        }
        return num;
    }

}
