package persistence;

import business.entities.League;
import business.entities.Match;
import business.entities.Team;

import java.util.ArrayList;

public interface LeagueDAO {

    /**
     * Retrieves all leagues from the data source.
     *
     * @return an ArrayList of all leagues.
     */
    ArrayList<League> getAll();

    /**
     * Saves a league in the data source.
     *
     * @param league the league to be saved.
     * @return true if the league is successfully saved, false otherwise.
     */
    boolean save(League league);

    /**
     * Checks if a league name is unique.
     *
     * @param name the league name to check.
     * @return true if the league name is unique, false otherwise.
     */
    boolean nameUnique(String name);

    /**
     * Retrieves leagues associated with the given team names.
     *
     * @param teamNames an ArrayList of team names.
     * @return an ArrayList of leagues associated with the teams.
     */
    ArrayList<League> getLeaguesByTeam(ArrayList<String> teamNames);

    /**
     * Deletes multiple leagues from the data source.
     *
     * @param leagues an ArrayList of league names to delete.
     * @return true if all leagues are successfully deleted, false otherwise.
     */
    boolean deleteLeagues(ArrayList<String> leagues);

    /**
     * Retrieves teams associated with a league.
     *
     * @param leagueName the name of the league.
     * @return an ArrayList of teams associated with the league.
     */
    ArrayList<Team> getTeamsByLeague(String leagueName);

    /**
     * Adds a team to a league in the data source.
     *
     * @param league the league to add the team to.
     * @param team   the team to add.
     * @return true if the team is successfully added to the league, false otherwise.
     */
    boolean addTeam(League league, String team);

    /**
     * Updates the score for a team in a league.
     *
     * @param teamName   the name of the team.
     * @param leagueName the name of the league.
     * @param won        the number of matches won.
     * @param lost       the number of matches lost.
     * @param tied       the number of matches tied.
     * @return true if the score is successfully updated, false otherwise.
     */
    boolean updateScore(String teamName, String leagueName, int won, int lost, int tied);

    /**
     * Updates the match day for a match in the data source.
     *
     * @param match the match to update.
     * @return true if the match day is successfully updated, false otherwise.
     */
    boolean updateMatchDay(Match match);

    /**
     * Retrieves the number of teams in a league.
     *
     * @param league the name of the league.
     * @return the number of teams in the league.
     */
    int getNumberTeams(String league);
}