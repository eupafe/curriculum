package business;

import business.entities.Team;
import business.entities.User;

import java.util.ArrayList;

public interface TeamInterface {
    /**
     * Validates the team data from the specified file path.
     *
     * @param path the file path to validate
     * @return the validation result as an integer:
     *         0 - validation successful
     *         1 - team name already exists
     *         2 - player email incorrectly formatted
     *         3 - player squad number not positive integer or 0
     *         4 - player DNI incorrectly formatted
     */
    int validateTeam(String path);

    /**
     * Deletes the teams with the specified names.
     *
     * @param teams the names of the teams to delete
     * @return true if the teams were successfully deleted, false otherwise
     */
    boolean deleteTeams(ArrayList<String> teams);

    /**
     * Creates a new team based on the data in the specified file.
     *
     * @param path the file path containing the team data
     * @return true if the team was successfully created, false otherwise
     */
    boolean createTeam(String path);

    /**
     * Retrieves all the teams.
     *
     * @return a list of all teams
     */
    ArrayList<Team> getAllTeams();

    /**
     * Retrieves the players belonging to the specified team.
     *
     * @param teamName the name of the team
     * @return a list of players belonging to the team
     */
    ArrayList<User> getPlayersByTeam(String teamName);
}
