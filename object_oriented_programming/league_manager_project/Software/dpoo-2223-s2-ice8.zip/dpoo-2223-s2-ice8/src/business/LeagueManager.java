package business;

import business.entities.*;
import persistence.ConfigJSONDAO;
import persistence.LeagueSQLDAO;
import persistence.MatchSQLDAO;
import persistence.TeamSQLDAO;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class LeagueManager implements LeagueInterface{

    private LeagueSQLDAO leagueDao;
    private MatchSQLDAO matchDao;
    private TeamSQLDAO teamDao;
    private ConfigJSONDAO configDao;

    /**
     * Constructs a LeagueManager with the specified DAO instances.
     * @param leagueSQLDAO the DAO for league operations
     * @param matchSQLDAO  the DAO for match operations
     * @param teamSQLDAO   the DAO for team operations
     */
    public LeagueManager(LeagueSQLDAO leagueSQLDAO, MatchSQLDAO matchSQLDAO, TeamSQLDAO teamSQLDAO) {
        leagueDao = leagueSQLDAO;
        matchDao = matchSQLDAO;
        teamDao = teamSQLDAO;
        configDao = new ConfigJSONDAO();
    }

    /**
     * Creates a new league with the specified name, start date, and start time.
     * @param name       the name of the league
     * @param startDate  the start date of the league
     * @param startTime  the start time of the league
     */
    @Override
    public void createLeague(String name, LocalDate startDate, LocalTime startTime) {
        leagueDao.save(new League(name, startDate, startTime));
    }

    /**
     * Validates the league by checking if the name is unique and the start date is in the future.
     * @param name       the name of the league
     * @param startDate  the start date of the league
     * @param startTime  the start time of the league
     * @return true if the league is valid, false otherwise
     */
    public boolean validateLeague(String name, LocalDate startDate, LocalTime startTime){

        if ( leagueDao.nameUnique(name) && !LocalDate.now().isAfter(startDate)) {
            return true;
        }
        else {
            return false;
        }

    }

    /**
     * Creates a calendar for the league with the specified name, start date, start time, and teams.
     * @param name        the name of the league
     * @param startDate   the start date of the league
     * @param startTime   the start time of the league
     * @param teams       the list of team names participating in the league
     */
    @Override
    public void createCalendar(String name, LocalDate startDate, LocalTime startTime, ArrayList<String> teams) {

        League league = new League(name, startDate, startTime);

        /*in an array list of 6
        [1, 2, 3, 4, 5] [6] -> (6 v 5) (4 v 1) (3 v 2)
        [2, 3, 4, 5, 1] [6] -> (6 v 1) (5 v 2) (4 v 3)
        [3, 4, 5, 1, 2] [6] -> (6 v 2) (1 v 3) (5 v 4)
        [4, 5, 1, 2, 3] [6] -> (6 v 3) (2 v 4) (1 v 5)
        [5, 1, 2, 3, 4] [6] -> (6 v 4) (3 v 5) (2 v 1)
        rotation x2
        everyone plays twice, if number of teams is odd add a null team
        and whoever plays against this null team is sitting out for the day
         */
        for (String team: teams) {
            leagueDao.addTeam(league, team);
        }

        String stationed = teams.get(teams.size() - 1);
        teams.remove(stationed);
        //if teams is uneven add a null team
        if (teams.size() % 2 == 0) {
            teams.add(null);
        }

        int duration = configDao.getMatchDuration();
        ArrayList<Match> matches = new ArrayList<>();

        for (int matchDay = 0; matchDay < teams.size() * 2; matchDay++) {
            int last = teams.size() - 1;
            int first = 0;

            if (teams.get(last) != null) {
                matchDao.save(new Match(stationed, teams.get(last), league.getName(), matchDay + 1, league.getStartDay(), league.getStartTime().plusMinutes(3*matchDay), duration, 0));
                //matches.add(new Match(stationed.getName(), teams.get(last).getName(), league.getName(), matchDay + 1, league.getStartDay().plusDays(matchDay), league.getStartTime(), 2, false, 0));
            }
            while (last > first) {
                if (teams.get(last - 1) != null && teams.get(first) != null) {
                    matchDao.save(new Match(teams.get(last - 1), teams.get(first), league.getName(), matchDay + 1, league.getStartDay(), league.getStartTime().plusMinutes(3*matchDay), duration, 0));
                    //matches.add(new Match(teams.get(last - 1).getName(), teams.get(first).getName(), league.getName(), matchDay + 1, league.getStartDay().plusDays(matchDay), league.getStartTime(), 2, false, 0));
                }
                first++;
                last--;
            }

            //rotate
            String temp = teams.get(0);
            for (int i = 0; i < teams.size() - 1; i++) {
                teams.set(i, teams.get(i+1));
            }
            teams.set(teams.size() - 1, temp);

        }
    }

    /**
     * Returns the list of leagues associated with the given user.
     * @param user  the user for whom to retrieve the leagues
     * @return the list of leagues
     */
    @Override
    public ArrayList<League> getLeagues(User user) {
        if (user == null) {
            return leagueDao.getAll();
        }
        else {
            ArrayList<Team> teams = teamDao.getTeamsByUser(user.getDNI());
            ArrayList<String> teamNames =new ArrayList<>();
            for (Team team : teams) {
                teamNames.add(team.getName());
            }
            return leagueDao.getLeaguesByTeam(teamNames);
        }
    }

    /**
     * Deletes the leagues specified in the list.
     * @param leagues  the list of league names to delete
     * @return true or false depending on the dao deletion
     */
    @Override
    public boolean deleteLeagues (ArrayList<String> leagues){
        return leagueDao.deleteLeagues(leagues);
    }

    /**
     * Returns the list of teams participating in the given league.
     * @param leagueName   the name of the league
     * @return the list of teams
     */
    @Override
    public ArrayList<Team> getTeamsByLeague(String leagueName) {
        return leagueDao.getTeamsByLeague(leagueName);
    }

    /**
     * Returns the statuses of the leagues associated with the specified user.
     */
    @Override
    public ArrayList<String> getLeaguesStatus(User user) {
        ArrayList<String> statuses = new ArrayList<>();

        ArrayList<League> leagues = getLeagues(user);

        for (League league: leagues) {
            boolean completed = true;
            boolean notStarted = true;
            ArrayList<Match> matches = matchDao.getMatchesByLeague(league.getName());
            for (Match match: matches) {
                completed &= (match.getResult() > 1);
                notStarted &= (match.getResult() == 0);
            }
            //get the status
            if (completed) {
                statuses.add("Complete");
            }
            else if (notStarted) {
                statuses.add("Not started");
            }
            else {
                statuses.add("In progress");
            }
        }
        return statuses;
    }

    /**
     * Returns the number of teams in each league associated with the specified user.
     * @param user  the user for which to retrieve the number of teams in each league
     * @return the list of numbers of teams in each league associated with the user
     */
    @Override
    public ArrayList<Integer> getLeaguesNumberTeams(User user) {
        ArrayList<Integer> numTeams = new ArrayList<>();

        ArrayList<League> leagues = getLeagues(user);
        int number;
        for (League league: leagues) {
            //get the number of teams
            number = leagueDao.getNumberTeams(league.getName());
            numTeams.add(number);
        }
        return numTeams;
    }

    /**
     * Method that returns the number of won games for each team in the specified league.
     * @param leagueName  the name of the league
     * @return the list of numbers of won games for each team in the league
     */
    @Override
    public ArrayList<Integer> getTeamsWonGames(String leagueName) {
        ArrayList<Team> teams = getTeamsByLeague(leagueName);

        ArrayList<Integer> wonGames = new ArrayList<>();
        for (Team team: teams) {
            wonGames.add(teamDao.getWonGames(team.getName(), leagueName));
        }
        return wonGames;
    }

    /**
     * Function that returns the number of lost games for each team in the specified league.
     * @param leagueName  the name of the league
     * @return the list of numbers of lost games for each team in the league
     */
    @Override
    public ArrayList<Integer> getTeamsLostGames(String leagueName) {
        ArrayList<Team> teams = getTeamsByLeague(leagueName);

        ArrayList<Integer> lostGames = new ArrayList<>();
        for (Team team: teams) {
            lostGames.add(teamDao.getLostGames(team.getName(), leagueName));
        }
        return lostGames;
    }

    /**
     * Function that returns the number of tied games for each team in the specified league.
     * @param leagueName  the name of the league
     * @return the list of numbers of tied games for each team in the league
     */
    @Override
    public ArrayList<Integer> getTeamsTiedGames(String leagueName) {
        ArrayList<Team> teams = getTeamsByLeague(leagueName);

        ArrayList<Integer> tiedGames = new ArrayList<>();
        for (Team team: teams) {
            tiedGames.add(teamDao.getTiedGames(team.getName(), leagueName));
        }
        return tiedGames;
    }

    /**
     * Function that returns the number of players in each team participating in the specified league.
     * @param leagueName  the name of the league
     * @return the list of numbers of players in each team participating in the league
     */
    @Override
    public ArrayList<Integer> getTeamsNumberPlayers(String leagueName) {
        ArrayList<Team> teams = getTeamsByLeague(leagueName);

        ArrayList<Integer> numberPlayers = new ArrayList<>();
        for (Team team: teams) {
            numberPlayers.add(teamDao.getNumberPlayers(team.getName()));
        }
        return numberPlayers;
    }

    /**
     * This function returns the statistics for each team in the specified league.
     * @param leagueName  the name of the league
     * @return the list of statistics for each team in the league
     */
    public ArrayList<Statistics> getStatisticsByLeague(String leagueName) {
        ArrayList<Statistics> statistics = new ArrayList<>();

        ArrayList<Team> teams = getTeamsByLeague(leagueName);
        for (Team team: teams) {
            statistics.add(new Statistics(team.getName(), matchDao.getPoints(leagueName, team.getName())));
        }
        return statistics;
    }
}
