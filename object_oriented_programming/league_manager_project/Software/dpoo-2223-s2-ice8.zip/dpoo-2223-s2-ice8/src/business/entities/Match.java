package business.entities;

import java.time.*;
import java.util.Observable;
import java.util.Random;

public class Match extends Observable {
    private final String team1;
    private final String team2;
    private final String leagueName;
    private final int matchDay;
    private final LocalDate date;
    private final LocalTime time;
    private final int duration; //time in minutes that the match should take to complete
    private int result; //0 is match is not finished, 1 is that the match is in progress, 2 is that team 1 has won, 3 is that team 2 has won and 4 is that they tied
    private int team1Score;
    private int team2Score;
    private boolean stop;

    /**
     * Constructor
     * @param team1
     * @param team2
     * @param league_name
     * @param matchDay
     * @param date
     * @param time
     * @param duration
     * @param result
     */

    public Match(String team1, String team2, String league_name, int matchDay, LocalDate date, LocalTime time, int duration, int result) {
        this.team1 = team1;
        this.team2 = team2;
        this.leagueName = league_name;
        this.matchDay = matchDay;
        this.date = date;
        this.time = time;
        this.duration = duration;
        this.result = result;
        this.team1Score = 0;
        this.team2Score = 0;
        this.stop = false;
    }

    /**
     * Method that returns the first team.
     * @return String
     */
    public String getTeam1() {
        return team1;
    }

    /**
     * Gets the name of team 2.
     * @return the name of team 2
     */
    public String getTeam2() {
        return team2;
    }

    /**
     * Gets the name of the league.
     * @return the name of the league
     */

    public String getLeagueName() {
        return leagueName;
    }

    /**
     * Gets the date of the match.
     * @return the date of the match
     */
    public LocalDate getDate() {
        return date;
    }

    /**
     * Gets the time of the match.
     * @return the time of the match
     */
    public LocalTime getTime() {
        return time;
    }

    /**
     * Gets the duration of the match in minutes.
     * @return the duration of the match in minutes
     */
    public int getDuration() {
        return duration;
    }

    /**
     * Gets the match day.
     * @return the match day
     */
    public int getMatchDay() {
        return matchDay;
    }

    /**
     * Gets the current result of the match.
     * @return the current result of the match
     */
    public int getResult() {
        return result;
    }

    /**
     * Gets the score of team 1.
     * @return the score of team 1
     */
    public int getTeam1Score() {
        return team1Score;
    }

    /**
     * Gets the score of team 2.
     * @return the score of team 2
     */
    public int getTeam2Score() {
        return team2Score;
    }

    /**
     * Simulates the match by updating the scores at random intervals until the match is completed.
     */

    public void simulateMatch() {

        result = 1; //Match is currently being simulated

        setChanged();
        notifyObservers();

        Random random = new Random();
        int timeToSleep;

        long end = System.currentTimeMillis() + (long) duration * 60 * 1000;
        while (System.currentTimeMillis() < end && !stop) {
            timeToSleep = 15000 * (random.nextInt(3) + 1);
            try {
                Thread.sleep(timeToSleep);

            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            synchronized (this) {
                if (random.nextInt(2) == 0) {
                    team1Score += 1;
                } else {
                    team2Score += 1;
                }
            }
            setChanged();   //it needs to be updated
            notifyObservers();


            //System.out.println(team1 + ": " + scores[0] + " vs " + team2 + ": " + scores[0]);
        }
        //System.out.println("Match Finished Between " + team1 + " and " + team2);

        if (team1Score > team2Score) {
            result = 2;
        } else if (team1Score == team2Score) {
            result = 4;
        } else {
            result = 3;
        }

        setChanged();   //it needs to be updated
        notifyObservers();
    }


    /**
     * Stops the simulation of the match.
     */
    public void stopSimulation() {
        synchronized (this) {
            stop = true;
        }
    }

}
