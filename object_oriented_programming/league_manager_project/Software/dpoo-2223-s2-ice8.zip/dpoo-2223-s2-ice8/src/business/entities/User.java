package business.entities;
/**
 * The User class represents a user/player in the system.
 */
public class User {
    private String DNI;
    private String email;
    private String password;
    private String name;
    private int squadNumber;
    private String phone;

    /**
     * Constructs a User object with the specified user details.
     *
     * @param DNI           the DNI (identification number) of the user
     * @param email         the email address of the user
     * @param password      the password of the user
     * @param name          the name of the user
     * @param squadNumber   the squad number of the user
     * @param phone         the phone number of the user
     */
    public User(String DNI, String email, String password, String name, int squadNumber, String phone) {
        this.DNI = DNI;
        this.email = email;
        this.password = password;
        this.name = name;
        this.squadNumber = squadNumber;
        this.phone = phone;
    }

    /**
     * Gets the DNI (identification number) of the user.
     *
     * @return the DNI of the user
     */
    public String getDNI() {
        return DNI;
    }

    /**
     * Gets the email address of the user.
     *
     * @return the email address of the user
     */
    public String getEmail() {
        return email;
    }

    /**
     * Gets the password of the user.
     *
     * @return the password of the user
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password of the user.
     *
     * @param password the new password for the user
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Gets the name of the user.
     *
     * @return the name of the user
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the squad number of the user.
     *
     * @return the squad number of the user
     */
    public int getSquadNumber() {
        return squadNumber;
    }

    /**
     * Gets the phone number of the user.
     *
     * @return the phone number of the user
     */
    public String getPhone() {
        return phone;
    }
}
