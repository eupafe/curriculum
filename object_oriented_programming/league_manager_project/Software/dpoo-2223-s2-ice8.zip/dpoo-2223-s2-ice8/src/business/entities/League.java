package business.entities;

import java.time.*;

/**
 * The League class represents a sports league.
 */
public class League {

    private String name;
    private LocalDate startDay;
    private LocalTime startTime;

    /**
     * Constructs a League object with the specified name, start date, and start time.
     *
     * @param name       the name of the league
     * @param startDate  the start date of the league
     * @param startTime  the start time of the league
     */
    public League(String name, LocalDate startDate, LocalTime startTime) {
        this.name = name;
        this.startDay = startDate;
        this.startTime = startTime;
    }

    /**
     * Gets the name of the league.
     *
     * @return the name of the league
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the start date of the league.
     *
     * @return the start date of the league
     */
    public LocalDate getStartDay() {
        return startDay;
    }

    /**
     * Gets the start time of the league.
     *
     * @return the start time of the league
     */
    public LocalTime getStartTime() {
        return startTime;
    }

}