package business.entities;

/**
 * The Team class represents a sports team.
 */
public class Team {
    private String name;

    /**
     * Constructs a Team object with the specified name.
     *
     * @param name  the name of the team
     */
    public Team(String name) {
        this.name = name;
    }

    /**
     * Gets the name of the team.
     *
     * @return the name of the team
     */
    public String getName() {
        return name;
    }
}
