package business.entities;

import java.util.ArrayList;

/**
 * The Statistics class represents the statistics of a team within a league.
 */
public class Statistics {
    private String teamName;
    private ArrayList<Integer> points;

    /**
     * Constructs a Statistics object with the specified team name and points.
     *
     * @param teamName  the name of the team
     * @param points    the points of the team
     */
    public Statistics(String teamName, ArrayList<Integer> points) {
        this.teamName = teamName;
        this.points = points;
    }

    /**
     * Gets the name of the team.
     *
     * @return the name of the team
     */
    public String getTeamName() {
        return teamName;
    }

    /**
     * Gets the points of the team.
     *
     * @return the points of the team
     */
    public ArrayList<Integer> getPoints() {
        return points;
    }
}
