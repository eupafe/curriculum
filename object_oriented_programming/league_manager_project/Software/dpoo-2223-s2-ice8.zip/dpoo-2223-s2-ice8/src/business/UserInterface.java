package business;

import business.entities.User;

import java.util.ArrayList;

public interface UserInterface {

    /**
     * Validates the login credentials.
     * @param username
     * @param password
     * @return true if the login credentials are valid, false otherwise
     */
    boolean loginIsValid(String username, String password);

    /**
     * Checks if the current user is a regular user or an admin
     * @return true if the user is a regular user, false if it's an admin
     */
    boolean isUser();

    /**
     * Deletes the user.
     * @return true if the user was currently deleted, false otherwise
     */
    boolean deleteUser();

    /**
     * Logs out the user.
     */
    void logOut();

    /**
     * Sets the user depedning on the username
     * @param login the user's login
     */
    void setUser(String login);

    /**
     * Creates missing players based on the data in the specified file.
     * @param path the file path containing the player data
     * @return a list of newly created players, or null if the file was not found
     */
    ArrayList<User> createMissingPlayers(String path);

    /**
     * Method that returns the password of the current user.
     * @return the password
     */
    String getPassword();

    /**
     * Updates the password of the current user.
     * @param password the new password to set
     */
    void updatePassword(String password);

    /**
     * Checks if the given password meets the password requirements.
     * @param password the password to check
     * @return true if the password meets the requirements, false otherwise
     */
    boolean checkPassword(String password);

    /**
     * Function that returns the current user.
     * @return the current user
     */
    User getUser();
}