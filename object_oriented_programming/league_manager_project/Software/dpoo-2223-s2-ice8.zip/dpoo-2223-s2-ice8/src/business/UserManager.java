package business;

import business.entities.User;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import persistence.ConfigJSONDAO;
import persistence.PlayerSQLDAO;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;

import org.passay.CharacterRule;
import org.passay.EnglishCharacterData;
import org.passay.PasswordGenerator;


public class UserManager implements UserInterface {

    private User user;
    private final PlayerSQLDAO dao;
    private final Gson gson;

    /**
     * Constructor that initializes the player sql DAO.
     * @param playerSQLDAO
     */
    public UserManager(PlayerSQLDAO playerSQLDAO) {
        this.dao = playerSQLDAO;
        this.gson = new Gson();
    }

    /**
     * Method that checks if the login is valid depending on the user.
     * @param login
     * @param password
     * @return true if it's valid, false otherwise
     */
    @Override
    public boolean loginIsValid(String login, String password) {
        if (login.equals("admin") || login.equals("Admin") || login.equals("ADMIN")){
            return password.equals(getAdminPassword());
        }
        else {
            return dao.validate(login, password);
        }
    }

    /**
     * Method that sets the user depending on the username
     * @param login the user's login
     */
    @Override
    public void setUser(String login){
        if (login.equals("admin") || login.equals("Admin") || login.equals("ADMIN")){
            user = null;
        }
        else{

            if (!login.contains("@")){
                //Obtain user by DNI
                user = dao.getByDNI(login);
            }
            else{
                //Obtain user by Email
                user = dao.getByEmail(login);
            }
        }
    }

    /**
     * Function that returns the password stored in config.json
     * @return
     */
    private String getAdminPassword() {
        ConfigJSONDAO config = new ConfigJSONDAO();
        return config.getAdminPassword();
    }


    /**
     * Function that returns whether a user has been succesfully deleted or not.
     * @return true if dao deleted the user, false otherwise.
     */
    @Override
    public boolean deleteUser() {
        boolean ok = dao.delete(user);
        user = null;
        return ok;
    }

    /**
     * Method that sets the user to null.
     */
    @Override
    public void logOut() {
        user = null;
    }

    /**
     * Creates missing players based on the data in the specified file.
     * @param path the file path containing the player data
     * @return an arraylist of users
     */
    @Override
    public ArrayList<User> createMissingPlayers(String path) {
        //returns 1 if the new players were successfully created, 0 if not
        //looks through the json file and checks witht the DAO which players exists, removing the existing players from an array of users
        //creates all of the players that do not already exist
        ArrayList<User> newPlayers = new ArrayList<>();
        FileReader fileReader = null;
        try {
            fileReader = new FileReader(path);
            JsonObject jsonObject = gson.fromJson(fileReader, JsonObject.class);
            JsonArray players = jsonObject.getAsJsonArray("players");


            String DNI;
            String email;
            String password;
            String name;
            int squadNumber;
            String phone;

            for (JsonElement player: players)  {
                DNI = player.getAsJsonObject().get("dni").getAsString();
                email = player.getAsJsonObject().get("email").getAsString();
                if (!dao.playerExists(DNI, email)) {
                    name = player.getAsJsonObject().get("name").getAsString();
                    password = randomPassword();
                    squadNumber = player.getAsJsonObject().get("number").getAsInt();
                    phone = player.getAsJsonObject().get("phone").getAsString();

                    dao.save(new User(DNI, email, password, name, squadNumber, phone));
                    newPlayers.add(new User(DNI, email, password, name, squadNumber, phone));
                }
            }

        } catch (FileNotFoundException e) {
            return null;
        }

        return newPlayers;
    }

    /**
     * Function that generates a random password.
     * @return password
     */
    private String randomPassword() {
        CharacterRule LCR = new CharacterRule(EnglishCharacterData.LowerCase);
        LCR.setNumberOfCharacters(2);

        CharacterRule UCR = new CharacterRule(EnglishCharacterData.UpperCase);
        UCR.setNumberOfCharacters(2);

        CharacterRule DR = new CharacterRule(EnglishCharacterData.Digit);
        DR.setNumberOfCharacters(4);

        PasswordGenerator passGen = new PasswordGenerator();
        return passGen.generatePassword(8, LCR, UCR, DR);
    }

    /**
     * Function that checks who logs in
     * @return boolean depending if it's a regular user (true) or admin (false)
     */
    @Override
    public boolean isUser() {

        if (user == null){
            return false;
        }
        return true;

    }

    /**
     * Function that returns the user password.
     * @return
     */
    @Override
    public String getPassword() {
        return user.getPassword();
    }

    /**
     * Method that updates the user password.
     */
    @Override
    public void updatePassword(String password) {
        user.setPassword(password);
        dao.update(user);
    }

    /**
     * Function that checks if a password meets the requirements.
     * @param password the password to check
     * @return true if it does, false otherwise
     */
    @Override
    public boolean checkPassword(String password){
        if (password.length() >= 8 && containsLowerCase(password) && containsUpperCase(password) && containsNumber(password)){
            return true;
        }
        return false;
    }

    /**
     * This method checks if the password contains a lower case
     * @param password
     * @return true if it does, false otherwise
     */
    private boolean containsLowerCase(String password) {
        for (char c : password.toCharArray()) {
            if (Character.isLowerCase(c)) {
                return true;
            }
        }
        return false;
    }

    /**
     * This method checks if the password contains an upper case
     * @param password
     * @return true if it does, false otherwise
     */
    private boolean containsUpperCase(String password) {
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                return true;
            }
        }
        return false;
    }

    /**
     * This method checks if the password contains a number
     * @param password
     * @return true if it does, false otherwise
     */
    private boolean containsNumber(String password) {
        for (char c : password.toCharArray()) {
            if (Character.isDigit(c)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method that returns the User.
     */
    @Override
    public User getUser(){
        return user;
    }
}
