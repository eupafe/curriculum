package business;

import business.entities.Match;
import business.entities.User;
import persistence.LeagueSQLDAO;
import persistence.MatchSQLDAO;
import presentation.controller.MainController;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * The MatchManager class handles the management and simulation of matches.
 * It implements the Observer interface to receive updates from matches.
 * It also implements the MatchInterface for match operations.
 */
public class MatchManager implements Observer, MatchInterface{
    private ScheduledExecutorService scheduler;
    private MatchSQLDAO matchSQLDAO;

    private LeagueSQLDAO leagueSQLDAO;
    private List<Match> matchesInSimulation;

    private MainController mainController;
    private UserManager userManager;

    /**
     * Constructor that receives user manager and match, league daos.
     * @param userManager
     * @param matchSQLDAO
     * @param leagueSQLDAO
     */
    public MatchManager(UserManager userManager, MatchSQLDAO matchSQLDAO, LeagueSQLDAO leagueSQLDAO) {
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
        this.matchSQLDAO = matchSQLDAO;
        this.leagueSQLDAO = leagueSQLDAO;
        this.matchesInSimulation = Collections.synchronizedList(new ArrayList<>());
        this.mainController = null;
        this.userManager = userManager;
    }

    /**
     * Starts the match simulator by retrieving matches from the database and simulating those that are due for simulation.
     * It schedules periodic updates of the match simulator.
     */
    @Override
    public void startMatchSimulator() {
        ArrayList<Match> matches;
        matches = matchSQLDAO.getAll();
        for (Match match : matches) {
            if (timeToSimulate(match)) {
                match.addObserver(this);
                matchesInSimulation.add(match);
                simulateMatch(match);
            }
        }

        scheduler.scheduleAtFixedRate(this::updateMatchSimulator, 0, 15, TimeUnit.SECONDS);
    }

    /**
     * Stops the match simulator by removing all matches from simulation.
     */
    @Override
    public void stopMatchSimulator() {
        for (Match match: matchesInSimulation) {
            match.deleteObserver(this);
            matchesInSimulation.remove(match);
        }
    }

    /**
     * Updates the match simulator by retrieving new matches from the database and simulating those that are due for simulation.
     */
    @Override
    public void updateMatchSimulator() {

        ArrayList<Match> matches;
        matches = matchSQLDAO.getAll();

        for (Match match: matches) {
            if (!matchContains(match, new ArrayList<>(matchesInSimulation)) && timeToSimulate(match)) {

                match.addObserver(this);
                matchesInSimulation.add(match);
                simulateMatch(match);
            }
        }
    }

    /**
     * This function updates from observed matches.
     * It updates the match result in the database, updates the score, and notifies the main controller for view updates.
     * @param o   the observed match object
     * @param arg the update argument (not used in this implementation)
     */
    @Override
    public void update(Observable o, Object arg) {
        Match match = (Match) o;
        matchSQLDAO.update(match);
        if (match.getResult() > 1) {
            updateScore(match);
            matchesInSimulation.remove(match);
            match.deleteObserver(this);
            mainController.updateStatistics();
        }
        //call controller to update view
        mainController.updateSimulation(getUserMatches(userManager.getUser()));
        //viewMockUp();
    }

    /**
     * Checks if it's time to simulate the given match.
     * The match is ready for simulation if its result is 0 and the current date and time match the match's date
     * @param match
     * @return true if it's time to simulate the match, false otherwise
     */
    private boolean timeToSimulate(Match match) {
        LocalDate currentDate = LocalDate.now();
        LocalTime currentTime = LocalTime.now();
        return match.getResult() == 0 && match.getDate().isEqual(currentDate) && match.getTime().getHour() == currentTime.getHour() && match.getTime().getMinute() == currentTime.getMinute();
    }

    /**
     * Checks if the given match is already in the list of matches.
     * @param matchToCheck
     * @param matchList
     * @return true if the match is already in the list, false otherwise
     */
    private boolean matchContains(Match matchToCheck, ArrayList<Match> matchList) {
        for (Match match: matchList) {
            if (matchToCheck.getTeam1().equals(match.getTeam1())
            && matchToCheck.getTeam2().equals(match.getTeam2())
            && matchToCheck.getLeagueName().equals(match.getLeagueName())
            && matchToCheck.getMatchDay() == match.getMatchDay()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Simulates the given match by starting a new thread for the match simulation.
     * @param match
     */
    private void simulateMatch(Match match) {
        //System.out.println("starting a match");
        Thread thread = new Thread(() -> match.simulateMatch());
        thread.start();
    }

    /**
     * Retrieves matches associated with the given user.
     * If the user is null, it returns all matches in simulation.
     * @param user the user to retrieve matches for
     * @return the list of matches associated with the user
     */
    @Override
    public ArrayList<Match> getUserMatches(User user) {
        if (user == null) {
            return new ArrayList<>(matchesInSimulation);
        }
        ArrayList<Match> matches;
        matches = matchSQLDAO.getMatchesByUser(user.getDNI());

        ArrayList<Match> userMatches = new ArrayList<>();
        for (Match match : matchesInSimulation) {
           if (matchContains(match, matches)) {
               userMatches.add(match);
           }
        }
        return userMatches;
    }

    /**
     * Updates the score based on the result of the given match.
     * It updates the scores of the winning and losing teams in the league.
     * @param match the match to update the score for
     */
    @Override
    public void updateScore(Match match) {

        //in has league update the winning teams matches won
        //in has league update the losing teams matches lost
        //if tied update both of the teams matches tied
        if (match.getResult() == 4) {
            leagueSQLDAO.updateScore(match.getTeam1(), match.getLeagueName(), 0, 0, 1);
            leagueSQLDAO.updateScore(match.getTeam2(), match.getLeagueName(), 0, 0, 1);
        }
        if (match.getResult() == 2) {
            leagueSQLDAO.updateScore(match.getTeam1(), match.getLeagueName(), 1, 0, 0);
            leagueSQLDAO.updateScore(match.getTeam2(), match.getLeagueName(), 0, 1, 0);
        }
        if (match.getResult() == 3) {
            leagueSQLDAO.updateScore(match.getTeam1(), match.getLeagueName(), 0, 1, 0);
            leagueSQLDAO.updateScore(match.getTeam2(), match.getLeagueName(), 1, 0, 0);
        }

        //update both teams scores where match day = match.match_day
        //score = matches_won
        leagueSQLDAO.updateMatchDay(match);

    }

    /**
     * Sets the main controller for this MatchManager.
     * @param mainController the main controller to set
     */
    @Override
    public void setController(MainController mainController){
        this.mainController = mainController;
    }

    /**
     * Forces closing of matches associated with the given league.
     * @param leagueName the name of the league to force close matches for
     */

    public void forceCloseMatchesByLeague(String leagueName) {
        ArrayList<Match> matches = matchSQLDAO.getMatchesByLeague(leagueName);
        for (Match match: matches) {
            forceClose(match);
        }
        mainController.updateSimulation(getUserMatches(userManager.getUser()));
    }

    /**
     * Forces closing of matches associated with the given team.
     * @param teamName the name of the team to force close matches for
     */
    public void forceCloseMatchesByTeam(String teamName) {

        ArrayList<Match> matches = matchSQLDAO.getMatchesByTeam(teamName);
        for (Match match: matches) {
            forceClose(match);
        }
        mainController.updateSimulation(getUserMatches(userManager.getUser()));
    }

    /**
     * Forces closing of the specified match.
     * It removes the match from the list of matches in simulation and stops the match's simulation.
     * @param matchRemove the match to force close
     */
    private void forceClose(Match matchRemove) {
        ArrayList<Match> matchesToDelete = new ArrayList<>();
        for (Match match: matchesInSimulation) {
            if (match.getTeam1().equals(matchRemove.getTeam1()) &&
                    match.getTeam2().equals(matchRemove.getTeam2()) &&
                    match.getLeagueName().equals(matchRemove.getLeagueName()) &&
                    match.getMatchDay() == matchRemove.getMatchDay()) {
                matchesToDelete.add(match);
            }
        }
        for (Match match: matchesToDelete) {
            match.deleteObserver(this);
            match.stopSimulation();
            matchesInSimulation.remove(match);
        }
    }
}
