package business;

import business.entities.Match;
import business.entities.User;
import presentation.controller.MainController;

import java.util.ArrayList;

public interface MatchInterface {

    /**
     * Starts the match simulator.
     */
    void startMatchSimulator();

    /**
     * Stops the match simulator.
     */
    void stopMatchSimulator();

    /**
     * Updates the match simulator.
     */
    void updateMatchSimulator();

    /**
     * Retrieves the list of matches associated with the specified user.
     *
     * @param user the user for which to retrieve the matches
     * @return the list of matches associated with the user
     */
    ArrayList<Match> getUserMatches(User user);

    /**
     * Updates the score of the specified match.
     *
     * @param match the match for which to update the score
     */
    void updateScore(Match match);

    /**
     * Sets the main controller for the match interface.
     *
     * @param mainController the main controller to set
     */
    void setController(MainController mainController);
}