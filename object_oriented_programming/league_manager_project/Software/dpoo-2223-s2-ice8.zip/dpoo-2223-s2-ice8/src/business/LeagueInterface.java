package business;

import business.entities.League;
import business.entities.Team;
import business.entities.User;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

/**
 * The LeagueInterface provides methods for managing leagues and teams.
 */
public interface LeagueInterface {
    /**
     * Creates a new league with the specified name, start date, and start time.
     * @param name        the name of the league
     * @param startDate   the start date of the league
     * @param startTime   the start time of the league
     */
    void createLeague(String name, LocalDate startDate, LocalTime startTime);

    /**
     * Creates a calendar for a league with the specified name, start date, start time, and an arraylist of teams.
     * @param name        the name of the league
     * @param startDate   the start date of the league
     * @param startTime   the start time of the league
     * @param teams       the list of team names participating in the league
     */
    void createCalendar(String name, LocalDate startDate, LocalTime startTime, ArrayList<String> teams);

    /**
     * Gets the list of leagues by User.
     * @param user  the user for whom to retrieve the leagues
     * @return the list of leagues for the user
     */
    ArrayList<League> getLeagues(User user);

    /**
     * Deletes the specified leagues.
     * @param leagues  the list of league names to delete
     * @return true if the leagues were successfully deleted, false otherwise
     */
    boolean deleteLeagues(ArrayList<String> leagues);

    /**
     * Gets the list of teams participating in the specified league.
     * @param leagueName   the name of the league
     * @return the list of teams participating in the league
     */
    ArrayList<Team> getTeamsByLeague(String leagueName);

    /**
     * Gets the status of the leagues by User.
     * @param user   the user for whom to retrieve the league statuses
     * @return the list of league statuses for the user
     */
    ArrayList<String> getLeaguesStatus(User user);

    /**
     * Gets the number of teams participating in each league by User.
     * @param user   the user for whom to retrieve the number of teams
     * @return the list of numbers of teams for each league of the user
     */
    ArrayList<Integer> getLeaguesNumberTeams(User user);

    /**
     * Gets the number of games won by each team given a League name.
     * @param leagueName   the name of the league
     * @return the list of numbers of games won by each team
     */
    ArrayList<Integer> getTeamsWonGames(String leagueName);

    /**
     * Gets the number of games lost by each team in the specified league.
     * @param leagueName   the name of the league
     * @return the list of numbers of games lost by each team
     */
    ArrayList<Integer> getTeamsLostGames(String leagueName);

    /**
     * Gets the number of games tied by each team given a league name.
     * @param leagueName   the name of the league
     * @return the list of numbers of games tied by each team
     */
    ArrayList<Integer> getTeamsTiedGames(String leagueName);

    /**
     * Gets the number of players in each team of the specified league.
     * @param leagueName   the name of the league
     * @return the list of numbers of players in each team
     */
    ArrayList<Integer> getTeamsNumberPlayers(String leagueName);
}