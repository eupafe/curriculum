package business;

import java.lang.reflect.Array;
import java.nio.file.Path;

import business.entities.Team;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import persistence.TeamSQLDAO;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import business.entities.User;
import persistence.PlayerSQLDAO;
import persistence.TeamSQLDAO;

public class TeamManager implements TeamInterface{

    private final Gson gson;
    private final TeamSQLDAO teamDao;

    /**
     * Constructs a new TeamManager.
     * @param teamSQLDAO the TeamSQLDAO implementation
     */
    public TeamManager(TeamSQLDAO teamSQLDAO) {
        this.gson = new Gson();
        this.teamDao = teamSQLDAO;
    }

    /**
     * Validates the team data from the given file path.
     * @param path the file path to validate
     * @return the validation result as an integer:
     *         0 - validation successful
     *         1 - team name already exists
     *         2 - player email incorrectly formatted
     *         3 - player squad number not positive integer or 0
     *         4 - player DNI incorrectly formatted
     */
    @Override
    public int validateTeam(String path) {
        try {
            FileReader fileReader = new FileReader(path);
            JsonObject jsonObject = gson.fromJson(fileReader, JsonObject.class);
            String teamName = jsonObject.get("team_name").getAsString();

            Pattern emailPattern = Pattern.compile("^(.+)@(.+)\\.(.+)$");
            Pattern dniPattern = Pattern.compile("^[0-9]{8,8}[A-Za-z]$");

            JsonArray players = jsonObject.getAsJsonArray("players");
            Boolean correctEmailFormat = true;
            Boolean numberPositive = true;
            Boolean correctDniFormat = true;
            Matcher emailMatcher;
            Matcher dniMatcher;
            for (JsonElement player: players)  {
                emailMatcher = emailPattern.matcher(player.getAsJsonObject().get("email").getAsString());
                dniMatcher = dniPattern.matcher(player.getAsJsonObject().get("dni").getAsString());
                //System.out.println("Email: " + player.getAsJsonObject().get("email").getAsString() + " Formatted: " + emailMatcher.matches());
                //System.out.println("Number: "+ player.getAsJsonObject().get("number").getAsInt() + " Is Positive: " + (player.getAsJsonObject().get("number").getAsInt() > 0);
                //System.out.println("Dni: " + player.getAsJsonObject().get("dni").getAsString() + " Formatted: " + dniMatcher.matches());
                correctEmailFormat &= emailMatcher.matches();
                numberPositive &= (player.getAsJsonObject().get("number").getAsInt() > 0);
                correctDniFormat &= dniMatcher.matches();

            }
            // if (team name exists) return 1;
            if (!teamDao.nameUnique(teamName)) {
                return 1;
            }
            // if (any players email is incorrectly formatted) return 2;
            if (!correctEmailFormat) {
                return 2;
            }
            // if (any players squad number is not positive integer or 0) return 3;
            if (!numberPositive) {
                return 3;
            }
            // if (any players DNI is incorrectly formatted) return 3;
            if (!correctDniFormat) {
                return 4;
            }

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        // if everything is fine return 0
        return 0;
    }

    /**
     * Deletes the teams given an arraylist of teams.
     * @param teams the names of the teams to delete
     * @return true if the teams were successfully deleted, false otherwise
     */
    @Override
    public boolean deleteTeams(ArrayList<String> teams) {
    	return teamDao.deleteTeams(teams);
    }

    /**
     * Creates a new team based on the data in the specified file.
     * @param path file path containing the team data
     * @return true if the team was successfully created, false otherwise
     */
    @Override
    public boolean createTeam(String path) {
        FileReader fileReader = null;
        try {
            fileReader = new FileReader(path);
            JsonObject jsonObject = gson.fromJson(fileReader, JsonObject.class);
            String teamName = jsonObject.get("team_name").getAsString();
            String DNI;
            teamDao.save(new Team(teamName));

            JsonArray players = jsonObject.getAsJsonArray("players");

            for (JsonElement player: players)  {
                DNI = player.getAsJsonObject().get("dni").getAsString();
                teamDao.saveMember(DNI, teamName);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        return true;
    }

    /**
     * Method that returns all the teams.
     * @return a list of all teams
     */
    @Override
    public ArrayList<Team> getAllTeams(){
        return teamDao.getAll();
    }

    /**
     * Gets the players by team name.
     * @param teamName the name of the team
     * @return a list of players belonging to the team
     */
    @Override
    public ArrayList<User> getPlayersByTeam(String teamName){
        return teamDao.getPlayersByTeam(teamName);
    }

}
