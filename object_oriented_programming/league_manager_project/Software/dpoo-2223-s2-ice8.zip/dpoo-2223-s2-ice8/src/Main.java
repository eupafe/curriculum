import business.LeagueManager;
import business.MatchManager;
import business.TeamManager;
import business.UserManager;

import persistence.*;
import presentation.controller.*;
import presentation.view.*;
import presentation.controller.LogInController;

public class Main {
    public static void main(String[] args) {

        // DAOs
        LeagueSQLDAO leagueSQLDAO = new LeagueSQLDAO();
        MatchSQLDAO matchSQLDAO = new MatchSQLDAO();
        TeamSQLDAO teamSQLDAO = new TeamSQLDAO();
        PlayerSQLDAO playerSQLDAO = new PlayerSQLDAO();

        // MANAGERS
        UserManager userManager = new UserManager(playerSQLDAO);
        TeamManager teamManager = new TeamManager(teamSQLDAO);
        LeagueManager leagueManager = new LeagueManager(leagueSQLDAO, matchSQLDAO, teamSQLDAO);
        MatchManager matchManager =  new MatchManager(userManager, matchSQLDAO, leagueSQLDAO);

        // VIEWS
        AddTeamsToLeagueView addTeamsToLeagueView = new AddTeamsToLeagueView();
        AdminMainView adminMainView = new AdminMainView();
        BaseView baseView = new BaseView();
        CreatedPlayersView createdPlayersView = new CreatedPlayersView();
        CreateLeagueView createLeagueView = new CreateLeagueView();
        DeleteLeagueView deleteLeagueView = new DeleteLeagueView();
        DeleteTeamView deleteTeamView = new DeleteTeamView();
        LeagueView leagueView = new LeagueView();
        LogInView logInView = new LogInView();
        MainWindow mainWindow = new MainWindow();
        PlayerMainView playerMainView = new PlayerMainView();
        StatisticsView statisticsView = new StatisticsView();
        TeamView teamView = new TeamView();
        ListTeamsView listTeamsView = new ListTeamsView();
        ListPlayersView listPlayersView = new ListPlayersView();


        LogInController loginController = new LogInController(logInView, userManager);
        LeagueController leagueController = new LeagueController(baseView, leagueView, createLeagueView,
                                            addTeamsToLeagueView, deleteLeagueView, listTeamsView, listPlayersView, statisticsView, teamManager, leagueManager, userManager, matchManager);
        TeamController teamController = new TeamController(baseView, teamView, deleteTeamView, createdPlayersView, teamManager, userManager, matchManager);
        MainController mainController = new MainController(mainWindow, logInView, baseView, adminMainView, teamView,
                                        leagueView, createLeagueView, addTeamsToLeagueView, deleteLeagueView, deleteTeamView,
                                        statisticsView, createdPlayersView, playerMainView, listTeamsView, listPlayersView, userManager, leagueManager, teamManager,
                                        loginController, leagueController, teamController, matchManager);
        matchManager.setController(mainController);
        mainController.start();

    }
}