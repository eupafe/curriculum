## OOPD PROJECT 2

by Group 8 on Monday 27th March 2023

## CONTACT

Laia Casas Irure - laia.casas@students.salle.url.edu
Eugènia Pacheco i Ferrando - eugenia.pacheco@students.salle.url.edu
Valèria Ezquerra Rodriguez - valeria.ezquerra@students.salle.url.edu
Daniel Hess - daniel.hess@students.salle.url.edu
Sebastian Félix Gorga - sebastianfelix.gorga@salle.url.edu

## LANGUAGE USED

The language that we used was Java and we have developed the project in IntelliJ IDEA. The SDKs that we use in this case was the 18 one. 

## INSTRUCTIONS FOR USE

A config.json must exist within the program. From there, the admin password can be changed in the admin_password section. 
If the administrator tries to log in with a different password, he/she will not be able to log in. In the same way,
if you want to change the database, all the aspects related to it: port, host, name, username and password can be changed from the same json.
## DATABASE DIAGRAMS
https://miro.com/app/board/uXjVMeNg_P0=/?share_link_id=192672073448

## GUI MOCKUPS
https://www.figma.com/file/mPdWhWtwaWL3KXjqqZJxdq/LEAGUE-MANAGER?node-id=0%3A1&t=fd10ZmihtUy762zN-1